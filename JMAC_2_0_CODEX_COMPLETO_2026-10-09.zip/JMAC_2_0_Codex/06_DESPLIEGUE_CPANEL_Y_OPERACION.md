# 06 · Instalación en cPanel, operación, respaldo y rollback

> Objetivo: instrucciones para instalar una aplicación PHP/MySQL **sin WordPress** en hosting con cPanel, sin requerir un servidor Node.js activo ni dominio externo de API. Estos pasos son la guía contractual para que Codex genere la documentación y el instalador reales. No se realizaron cambios en cPanel del usuario.

## 1. Compatibilidad que Codex debe comprobar ANTES de elegir stack

- PHP >= 8.3 preferible (comprobar versión y soporte concreto de framework), CLI PHP, extensiones `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `curl`, `xml`, `zip`, `intl` (si el host la posee), `gd` o `imagick` y `bcmath` si requiera formato monetario.
- Base de datos MySQL/MariaDB con versión, collation `utf8mb4`, límites de conexión, tamaño permitido y permisos para migrations.
- Directorio document root configurable a `/home/USER/jmac_app/public`, o posibilidad de servir únicamente el índice público sin exponer la app fuera de `public_html`.
- HTTPS AutoSSL/Let's Encrypt activo y válido para staging y dominio final.
- Cron jobs disponibles y frecuencia real; permitir `php artisan schedule:run` y una tarea finita de queue (`queue:work --stop-when-empty` / job con límites); no asumir daemon Supervisor.
- SMTP saliente con autenticación/TLS; configurar SPF/DKIM/DMARC en dominio si se usa email corporativo.
- SSH/Terminal/Composer si existe; si no, construir `vendor` y frontend por CI/local y subir paquete probado por SFTP/Administrador de archivos.
- Espacio libre para storage/media/backups, tiempo CPU y memoria PHP, máximo de subida, posibilidad de reescritura Apache y soporte de logs.

Crear `CPANEL_COMPATIBILITY.md` en el repo con resultados concretos, supuesto, bloqueo y solución.

## 2. Preparación

1. **Backup** del estado anterior sin ejecutarlo ni usarlo como origen de archivos públicos. Guardar copia fuera de document root y fuera del nuevo paquete de app.
2. Si el cPanel anterior se considera comprometido, recomendar hosting/cuenta nueva o limpieza certificada antes de desplegar. Rotar credenciales y revisar acceso de terceros.
3. Crear subdominio de staging (ej. `staging.jmaccr.com`) en carpeta/dominio separado, con acceso restringido y `noindex`, preferiblemente Basic Auth a nivel servidor.
4. Crear DB nueva, usuario DB nuevo y conceder privilegios mínimos aplicables; registrar valores en un gestor seguro. No compartir contraseñas en chat/documentos/repositorio.
5. Configurar `APP_URL`, zona `America/Costa_Rica`, SMTP y mecanismos de persistencia con `.env` server side.

## 3. Layout seguro

**Preferido:**

```text
/home/USUARIO/
  jmac_app/             ← todo Laravel, vendor, .env, storage, tests opcionales
    public/             ← DOCUMENT ROOT del dominio nuevo
      index.php
      build/
  backups_privados/     ← fuera del sitio web
```

Si cPanel no permite cambiar docroot del dominio principal, documentar la opción verificada de mantener proyecto completo fuera de `public_html` y solo un `index.php`, CSS/JS/media públicos dentro de `public_html`, con rutas bootstrap adaptadas a rutas reales de hosting y archivos privados inaccesibles. No copiar el framework completo a `public_html` ni usar `.htaccess` como única defensa de `.env` situado públicamente.

Evitar dependencia de symlinks si el host los deshabilita; servir media pública mediante rutas seguras o un directorio controlado. Permisos archivo normalmente `0644` y directorio `0755`, storage/cache con escritura restringida al usuario PHP según host. Evitar `0777`.

## 4. Build y despliegue reproducible

1. En estación de desarrollo/CI: `composer install --no-dev --prefer-dist --optimize-autoloader`, `npm ci && npm run build`, ejecutar tests antes del empaquetado, y generar manifest de checksums.
2. Preparar artefacto release con dependencias y `public/build` construidos; **no** incluir `.env` ni secretos; tampoco material WordPress anterior.
3. Transferir release a carpeta privada fuera del document root. Crear `.env` de producción en servidor desde `.env.example` y generar `APP_KEY` por comando seguro; validar conexión DB.
4. Ejecutar `php artisan migrate --force` una vez tras backup y validación del schema. Seed de roles/configuración únicamente: **comprobar categorías, marcas, productos, noticias y preventas en cero**.
5. Crear superadmin mediante comando de invitación de un solo uso/MFA inicial. No contraseñas default ni generadas en texto del README.
6. Preparar caches de Laravel apropiadas (`config:cache`, `route:cache`, `view:cache`), comprobar storage/web media y escritura de logs. Optimización segura sin cachear valores secretos en repositorio.
7. Configurar cron/queue con ruta real de PHP y carpeta app. Si el host soporta cron cada minuto:

```cron
* * * * * cd /home/USUARIO/jmac_app && /usr/local/bin/php artisan schedule:run >> /dev/null 2>&1
```

**Solo es un ejemplo**: Codex debe comprobar rutas y frecuencia reales de cPanel; si el proveedor limita a 5 minutos, ajustar expectativas y configurar trabajos no dependientes de resolución inmediata.

8. Configurar HTTPS real, cookies secure, APP_DEBUG=false, forzar HTTPS, cabeceras de seguridad y caché de assets versionados.
9. Comprobar pruebas de humo, flujo de contacto/preventa, datos vacíos, reportes, MFA, miniaturas, email de prueba, compatibilidad móvil.
10. Tras revisión y aprobación del propietario, realizar corte: backup y snapshot de DB, migrar cambios desde staging y apuntar dominio, conservar mecanismo de rollback y verificar SEO/SSL/correos.

## 5. Migraciones y semillas

El sitio NO debe ejecutar un importador de WP. El archivo `SEMILLA_CORPORATIVA_BORRADOR.json` es un origen opcional para **borradores**, no datos de catálogo ni publicaciones automáticas. Prohibido cargar histórico de categorías y productos. Al terminar instalación, consultar cuentas:

```sql
SELECT COUNT(*) AS total FROM products;
SELECT COUNT(*) AS total FROM categories;
SELECT COUNT(*) AS total FROM brands;
SELECT COUNT(*) AS total FROM preorders;
SELECT COUNT(*) AS total FROM posts;
```

Todas deben devolver `0`. Verificar que `users` contiene solo la cuenta nueva creada explícitamente y roles técnicos necesarios.

## 6. Backups, restauración y rollback

- Frecuencia propuesta: SQL diario y activos/media diario o incremental según cambios, retención configurable (ej. 7 diarias, 4 semanales, 3 mensuales); ajustar a capacidad del hosting. No dejar ZIP públicos en `public_html`.
- Cifrar backups y almacenarlos fuera del servidor o en almacenamiento externo seguro; documentar restauración sobre staging, verificar conteos, usuarios/permisos/archivos.
- Antes de actualizar app: punto de restauración de código + DB, ventana de mantenimiento breve, compatibilidad schema y release anterior listo. En migraciones no reversibles, plan escrito de restore.
- Monitorear emails no enviados, fallos cron, errores 500, disco lleno y certificados; alertas al administrador. Registrar backups exitosos y fallidos.
- Políticas de recuperación aproximadas RPO/RTO para propietario, **no** prometer horas sin medir servicio de hosting.

## 7. Checklist go-live de cPanel

- [ ] Nueva app instalada en carpeta segura, aislada de WordPress anterior.
- [ ] Revisión host y contraseñas/2FA completada.
- [ ] SSL válido/HTTPS redirige sin loops; mixed content 0.
- [ ] `.env`, `.git`, storage privado, ZIP/SQL y vendor inaccesibles vía navegador.
- [ ] Login admin/MFA, reset y control de permisos probados.
- [ ] Portada, nosotros, contacto, novedades, catálogo funcionan móvil/escritorio.
- [ ] Cero categorías, marcas, productos, noticias y preventas hasta carga desde admin.
- [ ] Alta de primer producto en staging, su publicación, filtrado, buscador y preventa probados, después eliminar datos de prueba.
- [ ] Emails/contactos persistidos con registro real y errores visibles.
- [ ] SEO/sitemap/canonical correctos, staging no indexado, production indexado solo páginas aprobadas.
- [ ] Backups y proceso de restore probados.
- [ ] Logs sin datos personales/secretos, debug OFF, sin PHP ejecutable en media.
- [ ] Conformidad visual/editorial del propietario.

## 8. Manuales obligatorios a Codex

`INSTALL_CPANEL.md` (capturas o pasos exactos de cPanel), `UPDATE_CPANEL.md`, `BACKUP_RESTORE.md`, `ADMIN_MANUAL.md` (para dueño que no programa), `TECHNICAL_ARCHITECTURE.md`, `SECURITY_CHECKLIST.md`, `.env.example`, `RELEASE_NOTES.md` y `TROUBLESHOOTING.md`. No marcar “instalado” si no se realizó deployment en hosting de prueba o no se recibió acceso/confirmación.
