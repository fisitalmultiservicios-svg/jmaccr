# Verificación y control de entrega

- Catálogo, categorías, marcas, usuarios antiguos, mensajes y preventas **NO** fueron exportados/importados al nuevo sistema.
- `CATALOGO_INICIAL_VACIO.csv` solo contiene encabezados de ejemplo; ninguna fila de producto.
- `SEMILLA_CORPORATIVA_BORRADOR.json`: listas `products`, `categories`, `brands`, `blog_posts`, `orders`, `customers` vacías.
- Se revisaron cuatro adjuntos originales (`themes.zip`, `uploads.zip`, `wpfd_posts.csv`, `wpfd_options.csv`) sin ejecutar scripts del tema.
- No se añaden al nuevo paquete `themes.zip`, `uploads.zip`, `.htaccess`, `.php` del WP antiguo, plugins, scripts, ZIP incrustados ni fuentes binarias.
- Los 10 recursos de `assets_limpios/` se obtuvieron por decodificación y re-guardado de imágenes del respaldo, no por copia de binarios ejecutables.
- `INFORME_CONSOLIDADO_JMAC_CODEX.pdf` se generó desde los 9 informes técnicos y se verificó que se abre correctamente. El PDF no incluye el prompt entero; usar `PROMPT_MAESTRO_CODEX.md` en Codex.
- Las páginas corporativas que carecen de contenido en export se identifican como tales; queda abierta extracción opcional de FSE (`EXTRACCION_OPCIONAL_FSE_SOLO_LECTURA.sql`).
- Una reconstrucción visual **exacta** no puede garantizarse con evidencia incompleta; el documento exige revisión del propietario para ese criterio.
- No se modificó ni accedió a configuración privada de cPanel del usuario: se entrega especificación, no sitio ya programado o instalado.
