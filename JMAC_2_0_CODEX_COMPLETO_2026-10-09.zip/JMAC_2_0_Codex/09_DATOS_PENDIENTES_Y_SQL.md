# 09 · Datos pendientes y consulta opcional de plantillas WordPress FSE

## 1. Importante: por qué las páginas del CSV no tienen texto

Se recibieron `wpfd_posts.csv` y `wpfd_options.csv`. La primera exportación recupera `post_type='page'`, pero en ella `Nosotros`, `Contacto` y `Novedades` tienen `post_content` vacío. Esto no autoriza inventar sus textos; el diseño anterior puede haberse generado en plantillas FSE guardadas en otra clase de registros. No era necesario Elementor: el tema Ona es de bloques WordPress Full Site Editing, que soporta plantillas y partes almacenadas como `wp_template`, `wp_template_part`, `wp_navigation` y `wp_block`.

**No necesitas regresar al wp-admin.** Si quieres mejorar la paridad de la web legítima, opcionalmente puedes consultar esas tablas desde phpMyAdmin con SQL de solo lectura y compartir el export filtrado. No es requisito para arrancar el desarrollo. **No es seguro ejecutar/importar** el HTML heredado directamente en la nueva app; primero revisarlo.

## 2. Consulta de plantillas y navegación

Usar `wpfd_posts` **solo si ese es el nombre real de tu tabla** (confirmarlo en phpMyAdmin). Ejecutar en la pestaña SQL y exportar resultados como CSV UTF-8. **Solo hace SELECT**:

```sql
SELECT
    ID, post_type, post_status, post_title, post_name,
    post_content, post_date, post_modified
FROM wpfd_posts
WHERE post_type IN ('wp_template', 'wp_template_part', 'wp_navigation', 'wp_block')
AND post_status IN ('publish', 'draft', 'private')
ORDER BY post_type, post_name, ID;
```

Antes de entregar el CSV: excluir scripts, inyecciones, enlaces ajenos y valores que expongan credenciales o datos privados. Si notas páginas claramente ajenas, descartarlas; no reutilizar su contenido.

## 3. Configuración adicional opcional del tema

Solo leer nombres de opciones primero, sin exportar todos sus valores:

```sql
SELECT option_name
FROM wpfd_options
WHERE option_name LIKE 'theme_mods_%'
   OR option_name LIKE 'wp_global_styles%'
   OR option_name LIKE 'ona_%'
ORDER BY option_name;
```

Un segundo export de **opciones específicas revisadas** puede ayudar a reconstruir colores, logos, menús o estilos. Las opciones pueden contener HTML, terceros, secretos o payloads maliciosos, así que no se deben enviar indiscriminadamente. El valor `stylesheet=ona-architecture` fue obtenido, pero no garantiza que esta plantilla representara el sitio de antes del ataque.

## 4. Material corporativo a confirmar con JMAC

| Campo | Valor actual | Acción |
|---|---|---|
| Nombre | JMAC | Confirmado |
| Lema | LIDER EN EL MERCADO INDUSTRIAL | Confirmado |
| Logo | `logo-jmac.png` del respaldo | Aprobación visual y derechos |
| Texto portada | Referencia indexada y banner original con ligera variante | Escoger redacción final |
| Teléfono comercial | **Sin verificar** | Configurar desde admin |
| WhatsApp | **Sin verificar** | Configurar desde admin |
| Email / remitente SMTP | **Sin verificar** | Configurar desde admin |
| Dirección y mapa | **Sin verificar** | Configurar desde admin |
| Redes sociales | **Sin verificar** | Configurar desde admin |
| Historia, misión, visión | **No recuperadas** | Redactar con dueño, no inventar |
| Páginas legales | Ejemplo WP no utilizable | Texto legal nuevo aprobado |
| Fotografía de personas | Re-guardada como candidato | Confirmar autorización de uso |
| Colores exactos / tipografía / layout | Parcial | Revisar mockup y aprobar |
| Portal antiguo de Reportes JMAC | Solo shortcode sin código | Definir si se recrea en admin |
| Catálogo anterior | **Decisión: no reutilizar** | Crear todo desde cero |

## 5. Qué no hace falta entregar

No enviar WordPress completo, `wp-admin`, `wp-includes`, plugins antiguos, respaldo completo sin depurar, usuarios/contraseñas, SQL con datos personales, archivos ejecutables, scripts sospechosos o catálogos históricos. El proyecto nuevo se construye sin ejecutar archivos del origen.

## 6. Criterio para cerrar la parte editorial

Al presentar maqueta de staging, JMAC debe aprobar: logo y variantes, portada/banner, menú, estructura de Nosotros, contacto, pie, colorimetría y textos. Codex guardará esas aprobaciones y documentará cualquier diferencia respecto al diseño histórico. Si no existen pruebas confiables para un detalle, marcar `reconstrucción propuesta`, nunca `réplica exacta comprobada`.
