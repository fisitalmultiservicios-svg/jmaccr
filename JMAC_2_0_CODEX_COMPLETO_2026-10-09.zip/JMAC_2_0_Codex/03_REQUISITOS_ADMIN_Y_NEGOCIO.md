# 03 · Backend administrativo integral, procesos y permisos

## 1. Principios del panel `/admin`

Panel propio **en español**, profesional, rápido en cPanel, centrado en propietarios no programadores. Menú lateral agrupado, buscador global administrativo, inicio claro, formularios con guardado/borrador, confirmación de cambios destructivos, avisos de éxito/fracaso, previsualización y soporte móvil. Todos los controles deben ser funcionales y conectados a BD.

**Estructura del menú propuesta:**

1. Inicio / estadísticas.
2. **Sitio web**: páginas, constructor visual, menús, encabezado y pie, banners, diseño global, multimedia.
3. **Catálogo**: categorías, subcategorías, marcas, productos, atributos, unidades, publicaciones, import/export **futuro**.
4. **Solicitudes**: preventas, contactos, seguimiento, plantillas de respuesta, notificaciones.
5. **Comunicación**: Novedades, enlaces y redes, formularios.
6. **SEO**: metadatos, redirecciones, sitemap, URL/robots.
7. **Sistema**: empresa, SMTP/canales, usuarios y permisos, auditoría, caché, salud, backups.

### Roles obligatorios

- `superadmin`: configuración y todos los accesos, 2FA obligatoria.
- `administrador`: contenido, catálogo, solicitudes y diseño, sin administrar secretos críticos salvo permiso explícito.
- `editor_web`: páginas, menús, diseño limitado, blog y medios; no ve datos personales de clientes por defecto.
- `gestor_catalogo`: categorías, marcas, productos, imágenes, fichas y estado publicado.
- `ventas`: ve/gestiona preventas y mensajes, no modifica diseño ni usuarios.
- `consulta`: solo lectura de funciones asignadas.

Permisos granulares en servidor: `pages.view/create/update/publish`, `theme.update`, `products.*`, `preorders.view/assign/update/export`, `contacts.*`, `settings.sensitive`, `users.manage`, `backups.restore`, etc. No confiar solo en esconder menús. Acciones masivas requieren permisos y confirmación.

## 2. CMS visual sin WordPress

### Requisitos de páginas

CRUD de páginas con título, ruta/slug único, plantilla, SEO, estado borrador/publicado/programado/archivado, identidad del editor y timestamps. Constructor de bloques permitidos, con arrastrar/reordenar, duplicar, ocultar, eliminar, edición inline de texto, selector multimedia, secciones reutilizables, controles de padding/columnas/espaciado/color por bloque, variante desktop/tablet/móvil. Vista previa protegida con token y/o sesión, accesible antes de publicar. Versionado por página y **restauración** de una revisión sin sobrescribir el historial.

### Biblioteca mínima de bloques

`hero`, `slider`, `heading`, `rich_text` seguro, `text_image`, `image`, `gallery`, `columns`, `icon_features` (iconos internos), `cta`, `buttons`, `testimonials` solo si aprobados, `contact_form`, `whatsapp`, `news_feed`, `catalog_categories`, `featured_products`, `spacer/divider`, `faq` opcional, `map` opcional. Esquemas JSON por tipo con reglas y valores por defecto; no permitir HTML arbitrario ni scripts. Añadir migraciones de esquema para evolución de bloques.

### Diseño global y componentes

Editor de colores, logo, favicon, fuentes, tamaños, fondos, enlaces, anchos, header/footer, CTA, estilos de tarjetas, variantes de nav y pie, mensaje de cookies, social sharing y enlaces externos. Tema visual versionado; publicación y rollback independientes. Mostrar comparativa antes/después. Evitar que editar colores bloquee accesibilidad: advertencias de contraste. Proveer un “Restablecer configuración visual” limitado a tokens, no borrar contenidos.

### Multimedia

Subida permitida: JPEG, PNG, WEBP, AVIF si servidor lo soporta y PDF verificado; MIME real, límite tamaño, nombre aleatorio, almacenamiento privado/seguro; redecodificación de imágenes para despojar metadatos y perfiles innecesarios, variantes retina y miniaturas, descripción y texto ALT. PDFs se servirán como descarga con encabezados, nunca ejecutar. No permitir `.php`, `.phtml`, SVG con scripts, `.htaccess`, ZIP ejecutables, contenido HTML ni archivos de scripts. Gestión de archivos no usados con comprobación de referencias antes de eliminar.

## 3. Catálogo completamente nuevo

**Regla innegociable**: en instalación limpia, `products=0`, `categories=0`, `brands=0`, `product_media=0`, `preorders=0` y `preorder_items=0`. No conservar inventario ni códigos viejos. No incluir “demo” visible. Las categorías históricas solo se mencionan en auditoría, **no se insertan**.

### Categorías

Nombre, slug único, descripción, categoría padre opcional, imagen, estado visible/oculta, orden. Permitir jerarquía y drag-sort, impedir ciclos padre-hijo, confirmación para eliminar categoría con productos, paginación y búsqueda. Contadores derivados, no fijos.

### Marcas

Nombre, slug único, logotipo, descripción, orden y estado. Puede iniciarse también con la marca J-MAC, **pero solo tras acción del administrador**. No precargarla automáticamente en la tabla `brands`.

### Productos

- Identificador interno, SKU/código **único** (requerido al publicar, opcional en borrador), título, slug, resumen, descripción larga con HTML permitido por sanitizer.
- Categoría(s), marca, etiquetas, unidad de medida, materiales, medidas, especificaciones técnicas estructuradas nombre/valor/unidad, variaciones opcionales, PDFs técnicos.
- Imágenes múltiples, portada, orden galería, ALT por foto, recorte responsivo.
- Status `draft`, `published`, `hidden`, `archived`, sort_order, destacado, stock opcional, `request_only` por defecto.
- Precio campo opcional privado (CRC) sin obligar usarlo; no publicarlo ni utilizar checkout/pago online sin solicitud posterior.
- Botones `Guardar borrador`, `Publicar`, `Vista previa`, `Duplicar`, `Despublicar`, `Archivar` y borrado reversible.
- Validaciones de código/slug, control de colisiones y transacciones, índices en búsquedas, ordenamiento y paginación.
- Importación CSV **como herramienta futura** para productos que el propietario suministre después; asistente mapping/preview/validación/errores y rollback por lote. **No ejecutar importación histórica como parte de la migración**.
- Exportación CSV/XLSX futura, solo usuarios autorizados, control de límites y protección contra CSV formula injection.

### Primera experiencia vacía

Público: portada sigue funcionando y catálogo presenta estado vacío administrable. Admin: CTA `Crear primera categoría`, `Crear primera marca`, `Agregar producto`; contar cero sin falsas métricas. Tests verifican que instalar no genera productos o categorías.

## 4. Preventas: proceso completo

**Dominio:** solicitud comercial, no compra pagada. El cliente arma una lista de ítems y envía datos; equipo de ventas revisa/contacta/cotiza fuera o dentro del módulo.

### Flujo público

1. Usuario entra al catálogo, filtra/busca.
2. Agrega ítems publicados con cantidad positiva, edita y remueve.
3. En carrito ve nombre/código/cantidad, y un formulario `Nombre`, `Teléfono`, `Empresa` (opcional), `Email` (opcional), `Observaciones` (opcional).
4. Valida consentimiento y antispam; envía petición HTTPS con token idempotente.
5. Backend valida cada ID contra publicaciones actuales, recrea snapshot de nombre/SKU/unidad, guarda en una transacción el consecutivo `JMAC-PV-AAAA-NNNNN` (formato configurable) y las líneas.
6. Tras commit, devuelve número y mensaje de recepción. Encola notificaciones con estado comprobable, no considera “enviada” si falla correo o API.
7. Panel administrativo muestra solicitud completa y timeline de cambios.

### Estados

`recibida -> en_revision -> cotizada -> gestionada -> cerrada`, con `cancelada` desde estados permitidos. No saltos arbitrarios sin privilegio. Registrar transición, fecha, usuario, nota; asignación de vendedor, etiquetas, filtros por fecha/estado/contacto, búsqueda por número/SKU. Mantener snapshot de datos de los productos si se borran o modifican posteriormente.

### Notificaciones

Correo SMTP a destinatarios configurados (plantilla HTML + texto), correo al cliente **solo si brinda email y autoriza**. WhatsApp: click-to-chat opcional (cliente inicia comunicación) o integración Business API oficial configurada por credenciales seguras; apertura de URL no es envío automático. Los logs deben registrar `pending/sent/failed` y reintentos limitados por cron. Evitar duplicados con clave idempotente y retriable outbox. Nunca exponer email/telef. en URL GET salvo click-to-chat consentido y controlado.

### Administración

Bandeja, detalle, cambio de estado, nota interna, asignación, filtros, exportar CSV/PDF, impresión A4 o térmica opcional futura, estadísticas de solicitudes por período, historial y alertas. Los formularios deben proteger datos personales; retención y borrado parametrizables.

## 5. Formularios de contacto

`contact_submissions` con nombre, teléfono, email, empresa, mensaje, estado, origen, fecha, consentimiento; con límites anti-spam/honeypot/reCAPTCHA opcional, listas de bloqueos y rate limit. Persistir primero, enviar correo después, nunca duplicar por recarga. Estados `nuevo`, `en_proceso`, `respondido`, `cerrado`, nota interna, responsable, búsqueda, descarga controlada y registro de borrado/anonymización.

## 6. Blog/Novedades

Crear/publicar/borrador, portada, editor WYSIWYG seguro, extracto, fecha, autora/o opcional, categorías/tags, SEO y OG, galería, vista previa, revisiones, programación (si cron soporta), comentarios **deshabilitados** salvo requerimiento explícito. Feed dinámico en Inicio solo si artículos publicados. **No importar antiguos posts** de la web comprometida.

## 7. Configuración, usuarios, herramientas y estadísticas

- `Datos empresa`: contactos, mapa, horario, razón social opcional, nombre, logo, redes, link WhatsApp validado.
- `Correos`: remitente, SMTP sin exponer contraseña tras guardado, envío de prueba autorizado, alertas de error.
- `SEO`: titles/descriptions, OG imagen, sitemap actualizado, robots, noindex de staging.
- `Usuarios`: invitar, activar/desactivar, MFA/2FA, restablecimiento seguro, roles; bitácora.
- `Diagnóstico`: versión app, PHP/extensiones, DB, cola/cron, espacio de disco, última copia verificada, last email failure, certificados de HTTPS si se consulta con seguridad.
- `Caché`: invalidación selectiva tras publicar y botón solo administradores; no borrar medios ni contenido al limpiar.
- `Respaldos`: instrucciones a nivel host y aplicación; backup automático programable si capacidades del hosting lo permiten; restauración solo Superadmin con doble confirmación.
- `Auditoría`: cada cambio de páginas, productos, diseño, preventas, permisos y configuraciones queda registrado; en cambios sensibles guardar diffs **sin secretos**.
- `Exportaciones`: estadísticas básicas, reporte por fecha/estado/categoría/producto una vez que existan datos; acceso controlado.

## 8. Operaciones del CMS que requieren aprobación

Nunca activar pasarela, publicar precios, importar catálogo viejo, migrar clientes, activar WhatsApp API, cambiar DNS, eliminar WordPress o reemplazar contenido en producción sin autorización explícita. Codex puede implementar estas capacidades como módulos optativos desactivados, pero no simular que ya están activas.
