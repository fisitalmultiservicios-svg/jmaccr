# 07 · QA, pruebas automatizadas y criterios de aceptación

## 1. Filosofía de prueba

Cada botón anunciado debe ejecutar acción real. Pruebas unitarias + Feature HTTP/BD + Browser/E2E según recursos del repositorio. Usar fixtures de ejemplo **solo** en test/staging y limpiar antes de instalación productiva. No enviar notificaciones reales a clientes durante pruebas. Capturar evidencia de resultados y fallos.

## 2. Matriz de aceptación

| ID | Módulo | Escenario | Resultado requerido |
|---|---|---|---|
| T001 | Instalación | BD `migrate:fresh --seed` | categorías=0, marcas=0, productos=0, noticias=0, preventas=0 |
| T002 | Sitio | GET `/`, `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/` | 200, diseño corporativo, sin WordPress/SEO basura |
| T003 | SEO | Sitemap/robots/canonical | 0 rutas basura, índice solo páginas publicadas |
| T004 | Diseño | Cambiar color/hero en admin y publicar | Front actualiza sin programar; borrador no altera público |
| T005 | Diseño | Restaurar revisión previa | Visual y contenido regresan, auditoría mantiene evento |
| T006 | Menú | Añadir/reordenar/ocultar enlace | Reflejado desktop/móvil, URL válida |
| T007 | Admin | Visita `/admin` sin login | 302 login o 401, nunca información sensible |
| T008 | Admin | Login incorrecto repetido | Rate limit, sin enumeración de usuario |
| T009 | Permisos | Rol ventas intenta cambiar tema/producto | HTTP 403, no alteración BD |
| T010 | Permisos | Rol editor intenta ver datos de preventas | HTTP 403 |
| T011 | MFA | Superadmin sin segundo factor configurado | Flujo de enrolamiento seguro obligatorio |
| T012 | Categorías | Crear categoría con imagen | Visible en catálogo en orden definido |
| T013 | Categorías | Duplicar slug o ciclo | Error validación, BD consistente |
| T014 | Productos | Crear borrador | No aparece públicamente |
| T015 | Productos | Publicar nuevo producto con SKU | Búsqueda nombre/SKU, ficha y galería funcional |
| T016 | Productos | SKU duplicado | Error validación sin sobrescribir |
| T017 | Productos | Archivar producto | Desaparece de nuevos carritos, preventas antiguas mantienen snapshot |
| T018 | Catálogo | `/catalogo/` vacío | 200, estado vacío elegante, cero datos ficticios |
| T019 | Búsqueda | Palabras con acentos, SKU, sin resultados | Respuesta correcta y paginada |
| T020 | Filtros | Enlace `?jmac_cat=cadenas` con categoría inexistente | Vista vacía válida, sin error 500 |
| T021 | Carrito | Agregar/quitar/modificar cantidad | Contador y resumen sincronizados |
| T022 | Preventa | Enviar datos incompletos | 422 o errores de campo, nada guardado |
| T023 | Preventa | Producto despublicado en carrito | Rechazo claro, no se inserta ítem inválido |
| T024 | Preventa | Enviar válida | Transacción confirmada, número único y snapshot |
| T025 | Preventa | Doble click/reintento misma idempotency_key | UNA sola solicitud, misma referencia |
| T026 | Preventa | Dos solicitudes simultáneas diferentes | Consecutivos únicos y consistentes |
| T027 | Preventa | SMTP caído | Solicitud guardada, outbox failed/pending visible, no falsa entrega |
| T028 | Preventa | Cambio de estado por ventas | Timeline y usuario registrado, notificación apropiada |
| T029 | Contacto | Formulario válido con correo caído | Contacto persiste en BD, error notificación rastreable |
| T030 | Contacto | spam/honeypot/rate limit | Bloqueo/rate limit sin afectar tráfico legítimo |
| T031 | Blog | Publicar/retirar novedad | Index y detalle correctos, SEO actualizado |
| T032 | Media | Subir JPG/PNG/WEBP válidos | Miniaturas + ALT + reencode |
| T033 | Media | Intentar PHP disfrazado `.jpg`/ZIP/SVG activo | Rechazo, nunca ejecución |
| T034 | XSS | Inyectar JS en editor/ficha/contacto | Escapado/sanitizado, sin ejecución |
| T035 | CSRF | POST modificación sin token | Rechazo, BD sin cambios |
| T036 | SQLi | `q` con caracteres especiales SQL | Resultado seguro, sin errores SQL ni fuga |
| T037 | Rendimiento | 1k productos simulados en test | Paginación sin cargar todo, tiempos medidos |
| T038 | Responsive | 360/390/768/1024/1440 px | Sin scroll horizontal anómalo, CTA accesible |
| T039 | Accesibilidad | Teclado/lector texto/labels/foco | Cumple controles básicos WCAG AA |
| T040 | cPanel | Instalar artefacto limpio | Web y admin funcionan sin servidor Node |
| T041 | cPanel | Visitar `/.env`, `/vendor/`, `/storage/logs/...` | Denegación consistente, sin filtración |
| T042 | cPanel | Cron/colas/SMTP | Procesan, registran éxito/error, no requieren daemon |
| T043 | Operación | Restaurar backup en staging | App recupera páginas, productos nuevos y usuarios autorizados |
| T044 | Auditoría | Cambiar roles/diseño/preventa | Registro de usuario/fecha/cambio, sin secretos |
| T045 | Migración | Buscar referencias antiguas en BD nueva | No existe ninguna fila heredada, ni productos históricos |
| T046 | Publicación | Referencias de assets | Solo `assets_limpios/` aprovados y nuevos uploads sanos |
| T047 | Seguridad | Inspección dependencia/hardcoded keys | No hay secretos/WordPress/malware en repo o release |
| T048 | Aprobación | Validación visual con dueño | Capturas y checklist aprobados, diferencias conocidas listadas |

## 3. Pruebas transversales

### UI

Pantallas desktop 1440 y móvil 390; además 360, 768, 1024. Verificar estados: vacío, cargando, éxito, error, paginación sin registros, formulario inválido, permiso insuficiente, teléfono/WhatsApp sin configurar. El diseñador no debe producir secciones rotas en pantalla pequeña.

### Rendimiento, métricas

Medir Lighthouse de staging en varias visitas; metas *orientativas* iniciales y sujetas a host/red: LCP <= 2.5 s, CLS <= 0.1, INP <= 200 ms en dispositivos/condiciones evaluadas, no prometer cumplimiento sin medición. TTFB y tamaño total de página documentados. Revisar consultas N+1 y utilización de memoria PHP.

### Seguridad

Pruebas 401/403, cookies Secure/HttpOnly/SameSite, Csrf, XSS, SQL injection, files upload, rutas privadas, open redirect, sniff, reset token expiry, MFA y exclusión de secretos de logs.

### Negocio

El sitio vacío no se ve roto; tras crear una categoría/producto desde el administrador, se publica correctamente. El operador recibe una preventa real con cantidad/código, cambia estados, usa el consecutivo y consulta notas. WhatsApp click-to-chat **no** se etiqueta como mensaje entregado.

## 4. Definición de terminado (DoD)

1. Código desplegable, dependencias fijadas y procedimientos reproducibles.
2. Tests relevantes verdes e informe de ejecución adjunto; bloqueos documentados si no hay hosting.
3. Panel real completo y permisos comprobados.
4. Front público y contenido corporativo aprobados por el propietario o marcados explícitamente como pendientes.
5. Catálogo real inicialmente cero, carga desde admin de cero y sin productos heredados.
6. Preventas/correo/contacto funcionan con fallas gestionadas.
7. Seguridad no depende de tema original y cPanel mantiene secretos fuera del público.
8. URLs históricas funcionan o redirigen según lista aprobada; sin páginas de terceros.
9. Respaldo/restauración y recuperación probados antes de corte DNS.
10. Manual de usuario para no programadores y guía cPanel paso a paso publicados con la versión.

Codex no puede marcar etapa terminada si solo hay componentes visuales sin backend, datos persistentes o seguridad real.
