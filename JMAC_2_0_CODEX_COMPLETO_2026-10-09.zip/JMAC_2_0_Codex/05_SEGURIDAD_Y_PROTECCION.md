# 05 · Seguridad, aislamiento de fuente comprometida y protección de datos

## 1. Regla máxima

**Crear un proyecto nuevo y limpio.** No ejecutar, copiar, instalar ni adaptar `themes.zip`, `uploads.zip` (como archivos sin filtrar), ni archivos PHP, HTML, JS, CSS, `.htaccess`, plugin, shortcode, extensión o ZIP encontrados en el hosting anterior. Las imágenes incluidas son únicamente candidatos re-guardados como raster. Los datos de CSV y de páginas son entrada no confiable, no código.

Hallazgo concreto: en `themes/ona-architecture/functions.php` hay contenido ofuscado con manejo de cookies, decodificación y carga dinámica. No es apto para servir de base ni como archivo para comparar funciones legítimas. No se requiere atribución del atacante: basta con **aislar y no reutilizar**. También se detectan registros de páginas claramente no corporativas y una inyección HTML en Catálogo. No importar nada de ello.

### Qué NO se hizo y qué no afirmar

No se realizó forense de servidor, revisión de logs, DNS completo, usuarios ni base integral. No puede afirmarse que todo el hosting quedó limpio ni que el dominio vuelve a servir contenido correcto. El paquete limpia la **selección de activos que se entrega**, no el alojamiento original.

## 2. Requisitos de aplicaciones

- Laravel o framework estable actualizado y versiones fijadas en `composer.lock` y lock JS; SCA/dependency audit en CI.
- Autenticación de sesión segura: hash `Argon2id`/bcrypt validado, rate limit de login, MFA/2FA TOTP para superadmins, regeneración de sesión y cookies `HttpOnly`, `Secure`, `SameSite=Lax/Strict` apropiado.
- CSRF en mutaciones web; API pública protegida por rate limit y validación/antispam; sin secretos en URLs.
- Middleware RBAC/policies **server-side** por entidad y acción, no solo menú oculto. Revalidar roles después de permisos editados, registrar cambios sensibles.
- Todo acceso a BD por ORM/queries parametrizados; nunca concatenar entrada del visitante en SQL.
- Escape salida por defecto; rich-text con allowlist sanitizada, no HTML arbitrario, inline scripts o `javascript:`. CSP realista y cabeceras `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`, HSTS tras comprobar HTTPS, frame protection según necesidades.
- Sanitización y verificación de imágenes: límite de bytes/píxeles, firma/MIME real, decoder confiable, reencode, rutas no controlables por usuario, nombres UUID/hash. Bloquear SVG activo y subida de PHP/PHTML/JS/ZIP/HTML.
- Ruta de subida segregada, sin permiso de ejecución y sin permitir `.htaccess` de usuario. `vendor`, `.env`, backups y logs **fuera** del document root.
- No enseñar stack traces/SQL/secretos en errores públicos. Logger con redacción de PII y retención razonable.
- Emails protegidos contra header injection; SPF/DKIM/DMARC de dominio configurados por proveedor. Rate limit tanto en envío como reintentos.
- Exportaciones y respaldos de registros personales solo roles autorizados, descarga temporal privada y registro de evento; impedir CSV injection al exportar.
- Password reset seguro con expiración y token de un solo uso; invalidar sesiones al desactivar usuario.

## 3. Seguridad de producción y cutover

1. Mantener sitio anterior aislado o en modo conservación de evidencia; no desplegar la nueva app dentro de un directorio con scripts viejos. Preferir cuenta de hosting/cPanel recién configurada o alojamiento limpiado profesionalmente.
2. Rotar claves comprometidas desde equipo seguro: cPanel, FTP/SFTP/SSH, MySQL, correos/SMTP, DNS/registrador y cualquier token. Revisar usuarios desconocidos y cron jobs; activar 2FA donde esté disponible.
3. Montar staging independiente en subdominio o entorno privado **sin indexación**. No apuntar el DNS de producción sin pruebas/permiso.
4. Copias de seguridad verificadas e inmutables del entorno nuevo; restauración ensayada. Mantener rollback del despliegue anterior (de la nueva app) sin reutilizar WordPress.
5. Revisar PHP mail transport, certificados, DNS y configuración TLS. El SSL debe tener dominio correcto y todas las rutas con HTTPS antes de aceptar preventas.
6. Deshabilitar listado de directorios, XMLRPC WP si quedara alguno en dominio viejo, evitar exposición de archivos `.sql`, `.zip` o `backup` en public_html.

## 4. Modelo básico de amenazas

| Riesgo | Mitigación verificable |
|---|---|
| Reutilizar malware del tema WP | Lista permitida imágenes raster re-guardadas; no PHP/JS/temas; escaneo repositorio nuevo |
| XSS en contenido CMS | Bloques tipados y sanitizer server-side, autoescape Blade, CSP |
| SQL injection | Query parametrizada, pruebas adversariales |
| CSRF edición/pedido | CSRF/session tokens y SameSite; tests 419 |
| Acceso no autorizado `/admin` | Auth, MFA, policies y tests 401/403 |
| Duplicar preventas por refresh | `idempotency_key` UNIQUE, transacción y locks |
| Archivos ejecutables en uploads | MIME/decoder, almacenamiento sin ejecución, rechazo extensiones |
| Privacidad de clientes | Minimización, RBAC, cifrado secretos, export restringido, retención |
| Falsificar entrega WhatsApp/mail | Outbox con estados por canal y observabilidad |
| Cache muestra contenido antiguo | Invalida por revisión publicada, cache versionado |
| Mala configuración cPanel | Document root solo `/public`, verify endpoint privado, check list |

## 5. Privacidad y consentimiento

Usar textos legales aprobados por asesoría local; no copiar `Privacy Policy` de muestra WordPress. Definir responsable, propósito, tiempo de retención, contacto para solicitudes de datos, cookies externas. Formularios capturan lo mínimo necesario para responder consultas y preventas. Permitir export/borrado/anonymización según reglas legales aplicables y preservar comprobación de consentimiento por versión cuando corresponda.

## 6. Revisión antes de despliegue

- `composer audit` / análisis dependencias, linters, tests y escaneo estático.
- Buscar en el repositorio artefactos sospechosos: `wp-`, `base64_decode` en lugares injustificados, `eval`, `shell_exec`, `exec`, archivos con `.php` dentro de uploads (escaneo no debe depender solo de patrones).
- Verificar cabeceras, cookies, credenciales, permisos OS, directorios, noexposure de `.env`, `storage`, `.git`, `vendor`.
- Revisar que el paquete final no contenga fuentes binarias exportadas del tema ni imágenes de apuestas o comercios ajenos.
- Validar que usuarios y datos comerciales empiezan sin migración anterior, excepto el superadmin nuevo explícitamente provisionado.
