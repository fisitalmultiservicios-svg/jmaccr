# 02 · Especificación detallada de contenido, identidad y frontend público

## 1. Objetivo editorial y gráfico

Reproducir la imagen corporativa **J-MAC for the Industry** usando material recuperado y aprobado, con acabado empresarial, industrial y profesional. El nuevo frontend debe mostrar contenido HTML semántico (no títulos embebidos únicamente en imágenes), funcionar rápido, ser accesible y verse correctamente en escritorio, tablet y móvil. No presentar WordPress, plantillas Ona ni su menú en el código final. Los colores definitivos se deciden desde el editor de marca y se aprueban en staging.

## 2. Estructura de navegación

| Ruta obligatoria | Objetivo | Estado inicial | Bloques clave |
|---|---|---|---|
| `/` | Portada corporativa | Borrador con texto candidato | Hero, valores, fotografías, CTA catálogo, secciones |
| `/nosotros/` | Perfil JMAC | Borrador vacío o mínimamente identificado | Intro, historia, misión/visión solo si se facilitan, galería, CTA |
| `/contacto/` | Captación de consultas | Lista cuando se configuren canales | Texto, formulario, contacto, mapa opcional, WhatsApp |
| `/novedades/` | Noticias corporativas | 0 publicaciones | Listado, filtros, paginación, detalle |
| `/catalogo/` | Catálogo editable desde cero | 0 categorías / 0 productos | Categorías, buscador, filtros, carrito de preventa |
| `/novedades/{slug}/` | Detalle de noticia | Al publicar | Artículo, metadatos, imagen, CTA |
| `/catalogo/{slug}/` | Detalle de producto opcional | Al cargar productos | Ficha, características, imágenes, agregar a preventa |
| `/politica-de-privacidad/` | Información legal propia | Pendiente de texto legal aprobado | Documento versionado |

`/reportes-jmac/` no se recreará por defecto. El shortcode histórico `[jmac_reportes_portal]` no revela su lógica. Si el propietario confirma necesidad de reportes, diseñar un módulo interno **nuevo** protegido por roles, nunca reconstruir accesos antiguos sin validación.

Encabezado global: logotipo, menú configurable `Inicio`, `Nosotros`, `Contáctanos`, `Novedades`, `Catálogo`; CTA opcional. Header sticky configurable con logotipo responsivo. Menú móvil accesible por teclado, botón con `aria-expanded`, overlay apropiado y foco visible. Los vínculos deben ser reales y conservar slugs históricos.

Pie: JMAC/eslogan, datos reales de contacto parametrizados, enlaces de redes si se configuran, créditos y aviso legal. Crédito “Desarrollado por Fisital” opcional y editable, nunca una dependencia a servicios externos.

## 3. Contenido conocido de Inicio `/`

Orden de bloques recomendado, editable en su totalidad:

1. **Hero grande**: imagen de ambiente de trabajo corporativo `portada-fotografia.jpg` (o `portada-banner-con-texto.jpg` solo como referencia), título **“UN PRODUCTO CON 20 AÑOS DE EXPERIENCIA”**, subtítulo **“Somos líderes gracias a la confianza que cada uno de nuestros clientes nos brinda día a día.”** Botón “Ver catálogo”, opcional “Conócenos”.
2. **Declaración de origen**: título “ORGULLOSAMENTE TICOS”, imagen corporativa opcional `orgullosamente-ticos.jpg`, texto complementario sujeto a aprobación.
3. **Experiencia, tecnología y calidad**: título “Unión de Experiencia, Tecnología y Calidad”, texto aprobado candidato “Nuestra propuesta de producto siempre se ha basado en la experiencia adquirida en la venta de productos de línea industrial por más de dos décadas.”, foto de ambiente industrial `produccion-industrial.jpg` o `corporativa-producto.jpg`.
4. **Acceso al catálogo**: bloque de categorías **dinámico**. Si no hay categorías aprobadas, mostrar CTA “Próximamente” configurable o esconder sección, sin botones falsos ni productos de relleno.
5. **CTA de contacto**: encabezado sencillo, botones a formulario/WhatsApp (WhatsApp oculto mientras no exista número validado).
6. **Novedades recientes**: últimas 3 publicadas; ocultar automáticamente si no existen.

No copiar los textos como una única imagen: H1, subtítulos y CTAs deben ser seleccionables, editables y legibles con tecnologías de asistencia. Si se usa el banner original con título sobreimpreso, crear alternativa accesible, evitar duplicar el texto visual y pedir aprobación.

## 4. Nosotros `/nosotros/`

El CSV registra la página, pero `post_content` está vacío. Debe crearse una página de diseño empresarial con los siguientes bloques **vacíos/editables**: hero/banner, presentación, historia, valores, experiencia, personas/fotos y CTA a contacto. **No inventar** fundador, fechas exactas, misión/visión, ubicación, distribución, certificaciones, cobertura ni números de clientes. No trasplantar textos de `jumacindustrial.com` aunque la marca aparezca vinculada en buscadores; JMAC y Jumac Industrial son entidades/marcas que requieren aprobación de relación jurídica y editorial.

Se puede proponer usar `corporativa-retrato.jpg` solo con autorización de la persona fotografiada. Otros recursos: `corporativa-producto.jpg`, `produccion-industrial.jpg`. Se recomienda alta calidad original y versiones WebP/AVIF generadas por el nuevo CMS.

## 5. Contacto `/contacto/`

Formulario de referencia pública con `Nombre completo`, `Teléfono`, `Correo electrónico`, botón `Enviar Mensaje` y WhatsApp. Nueva versión propuesta: campo `Mensaje` (requerido), `Empresa` (opcional), checkbox de consentimiento si corresponde a la política aprobada, honeypot antispam y alerta de privacidad. Validar longitud y formato tanto en servidor como navegador. Registrar cada consulta en DB, mostrar comprobante y enviar correo si está configurado. Nunca borrar consulta por fallo de correo.

Datos del negocio configurables desde Admin > Configuración > Empresa: nombre comercial, teléfonos, WhatsApp E.164, email destino, email público, dirección, horarios, enlaces Maps, Facebook, Instagram y otras redes. **Todo vacío salvo JMAC y eslogan**. Maps embebido es opcional y debe respetar preferencias de privacidad/cookies cuando aplique.

## 6. Novedades `/novedades/`

Listado de artículos exclusivamente nuevos: estado editorial, fecha publicación, título, extracto, miniatura, autor opcional, categoría, tags, filtros y paginación. Ficha SEO y botones para compartir opcionales. No se transfieren antiguas entradas ni noticias externas; la exportación aportada no contiene el post type `post`. La ausencia de noticias se maneja con vista vacía corporativa.

## 7. Catálogo `/catalogo/` nuevo

El frontend mantiene el concepto: categorías clicables, búsqueda por código/nombre, fichas de producto, fotos, botón **“Cargar al carrito”**, contador y **“Carrito de preventa”**. El catálogo inicialmente **no contiene** nada. El administrador tendrá que crear desde cero categorías, marcas y productos. Al no haber resultados, mostrar el encabezado/imagen corporativa y un estado vacío administrable: “Estamos actualizando nuestro catálogo. Contáctanos para consultar disponibilidad.” (texto **propuesto**, editable y no obligatorio).

### Comportamientos al cargar productos

- Categorías con imagen, título, orden de aparición y número de productos publicados.
- Búsqueda accent-insensitive por nombre, código/SKU y palabras clave, con debounce y paginación; sanitizar entradas.
- Filtros dinámicos por categorías/marcas/atributos disponibles; no mostrar filtros sin opciones.
- Cada producto: nombre, SKU, imágenes, breve descripción, CTA “Cargar al carrito”, ficha opcional con atributos técnicos, documento PDF descargable si autorizado.
- Sin precios ni pagos por defecto. Valores internos o cotizables pueden existir para futuro, pero **ocultos al público** salvo autorización expresa.
- Cantidad mínima 1, límite configurable, la suma/quita actualiza contador, mantener carrito del visitante por sesión local y validar cada línea en servidor al enviar.
- No permitir confirmar un producto despublicado; explicar al usuario si un ítem dejó de estar disponible.
- Persistir catálogo en base de datos y crear URL slug solo al guardar producto. Nunca importar registros históricos.
- Compatibilidad SEO con enlaces de categoría existentes `?jmac_cat=...`: mapear el slug con categorías nuevas si fueron creadas con ese slug. Si no existen, mostrar listado vacío, no 500/404 injustificado.

### Carrito de preventa

Campos: Nombre (obligatorio), Teléfono (obligatorio), Empresa (opcional), Email (opcional), Observaciones (opcional), detalle de líneas/cantidades, aviso de privacidad. CTA `Pre venta` o `Solicitar preventa` administrable. **No es checkout de pago**. Mostrar consecutivo al confirmar si DB guardó la solicitud; estados: recibido / en revisión / cotizado / gestionado / cerrado / cancelado. Notificar por email/WhatsApp según integración que exista; mensaje prellenado de WhatsApp solo abre aplicación y no prueba entrega. El registro en DB prevalece.

## 8. Diseño: sistema flexible sin desarrollador

Implementar tokens globales `--color-primary`, `--color-secondary`, `--color-text`, `--color-background`, `--color-muted`, `--radius-*`, `--space-*`, tamaños de heading, ancho de contenido, estilo botones y tipografías. Editor de escritorio/tablet/móvil para cambios de sección, con vistas previas y publicación separada de borrador. Permitir reemplazar imágenes, mover bloques, ajustar alineación/tamaño, fondo, texto, botones y visibilidad por página y breakpoint. Limitar opciones a composiciones compatibles para evitar rotura visual; no ofrecer inserción de JS/PHP arbitrario.

Colores preliminares basados en el logo azul/blanco, guardados como *propuesta*: azul principal `#174B91`, celeste secundario `#1C87BB`, tinta `#18263D`, blanco `#FFFFFF`. Estos **no** son colores auditados del sitio histórico. Las configuraciones de `Ona Architecture` incluyen un naranja genérico que no debe imponerse.

## 9. Diseño responsivo, accesibilidad y rendimiento

- Puntos de prueba: 360, 390, 768, 1024 y 1440 px; soporte de zoom 200%; control táctil mínimo 44 x 44 CSS px recomendado.
- HTML5 semántico, un único H1 visible por vista; jerarquía H2/H3, etiquetas explícitas, `alt` descriptivo, foco visible, contraste WCAG AA en texto funcional, navegación por teclado.
- Usar `loading="lazy"` para imágenes no visibles y carga prioritaria en LCP; `srcset`/`sizes`, formatos comprimidos; ningún asset original de 10–30 MB en homepage.
- CSS/JS compilados versionados y minificados; SSR Blade; cache HTTP controlado; no cargar todas las imágenes ni productos a la vez.
- Cookies esenciales de sesión/CSRF seguras; opcionales de analítica solo tras consentimiento cuando aplique.
- SEO: títulos y descripciones por página, canonical, Open Graph/Twitter, JSON-LD Organization/LocalBusiness solo con datos confirmados, productos sin precios inventados, robots, sitemap únicamente publicadas, redirecciones 301 si cambian slugs aprobados.
- Escribir textos en español de Costa Rica y formatos `₡` cuando eventualmente haya importes aprobados. Zona horaria `America/Costa_Rica`.

## 10. Referencia visual

El archivo `REFERENCIAS_DISENO.jpg` es una composición de la selección de imágenes de origen; **NO** una captura de toda la web. El archivo `MANIFIESTO_IMAGENES.csv` sirve para reconstruir a partir de piezas gráficas. Para aprobación visual final, solicitar capturas originales de una versión limpia o recibir aprobación expresa sobre la nueva maqueta. Nunca atribuir coincidencia exacta basándose solo en la temática de imágenes.
