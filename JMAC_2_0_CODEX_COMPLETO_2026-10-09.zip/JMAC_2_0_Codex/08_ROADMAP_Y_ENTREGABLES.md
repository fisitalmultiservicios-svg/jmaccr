# 08 · Plan de ejecución recomendado para Codex

## Hito 0 — Diagnóstico y arquitectura (sin tocar producción)

- Leer este paquete completo y la evidencia. Revisar repositorio destino e historia, si existe.
- Crear matriz `verificado/parcial/desconocido`, arquitectura, extensiones PHP cPanel y ADRs.
- Aprobar stack y uso de migraciones; diagramar permisos y entidades.
- Listar pendientes editoriales, sin bloquear tareas técnicas.
- Entregar checklist para dueño y demostrar repositorio limpio.

**Salida:** `ARCHITECTURE.md`, `CPANEL_COMPATIBILITY.md`, `SECURITY_BASELINE.md`, task board, diseño DB.

## Hito 1 — Infraestructura limpia

- Proyecto PHP estable, conexión DB, migrations, seeds solo roles/config y borradores corporativos, login/MFA/RBAC.
- Infraestructura CSS/JS SSR, documentación `.env.example`, tests, CI, staging.
- Configurar audit, policy, caching básico y subidas seguras.
- Demostrar que catálogo, marcas, categorías, posts y preventas inician cero.

**Puerta de avance:** tests de seguridad y datos vacíos verdes, login funcional, no WordPress.

## Hito 2 — Sitio público e identidad

- Templates Blade y bloques corporativos configurables.
- Inicio, Nosotros, Contacto, Novedades, Catálogo, menús y footer.
- Copiar selectivamente imágenes **ya re-guardadas**, convertir a tamaños web y hacer manual de media.
- Responsive, SEO base y estados vacíos.

**Puerta:** rutas reales 200, front usable móvil, no textos inventados, imágenes corporativas aprobables.

## Hito 3 — CMS/editor visual y marca

- Admin: páginas, biblioteca de bloques, preview por dispositivo, revisiones, publish/rollback, menús, medios, branding, portada, footer.
- Permitir cambiar prácticamente toda la apariencia sin desarrollador y restringir diseño que rompa UI.
- Tests de publicación/no publicación, control de roles y persistencia.

**Puerta:** propietario puede cambiar logo, hero, copy, colores, menús, secciones sin programar y con undo.

## Hito 4 — Catálogo nuevo desde cero

- CRUD categorías/subcategorías, marcas, productos, atributos, fotos, PDF, slugs, búsqueda/filtros.
- UI pública con carrito, productos destacados opcionales y estado vacío inicial.
- Importador futuro deshabilitado por defecto y **nunca ejecutar importación vieja**.

**Puerta:** crear primer producto desde admin en staging, encontrar por nombre/SKU, agregar al carrito; BD producción sin heredados.

## Hito 5 — Preventas, contactos y notificaciones

- DB transaccional, consecutivo seguro, snapshots, idempotencia, estados, workflow ventas.
- Formularios y bandejas, SMTP, outbox y WhatsApp configurable.
- Exportaciones y reportes básicos con protección de PII.

**Puerta:** 1 solicitud válida persistida, reintento sin duplicar, correo fallido rastreable y atención por roles.

## Hito 6 — Novedades, SEO avanzado, auditoría

- Editor blog nuevo, estados/revisiones, portada, sitemap, redirecciones 301, OG/schema.
- Registro cambios admin, análisis multimedia no usada, respaldo y salud del servidor.

**Puerta:** publicar noticia y rollback; no indexar admin/staging.

## Hito 7 — QA, cPanel y salida

- Tests integrales 48 casos, validación performance/a11y/responsive, revisión de seguridad.
- Preparar paquete release para cPanel; instalación staging y prueba de backups/rollback.
- Manuales y video/guía visual opcional, firma de aprobación.
- Cambio a producción solo tras permiso expreso del propietario.

**Puerta:** `07_PRUEBAS_Y_ACEPTACION.md` completo; reporte final de hallazgos y pendientes firmado.

## Política de entregas entre hitos

Al terminar cada hito Codex debe informar: archivos modificados, endpoints/páginas nuevos, screenshot o evidencia real del panel/usuario, tests ejecutados y resultados, riesgos, cambios de esquema, cómo desplegar y qué necesita del propietario. Solicitar clarificación solo cuando bloquea una decisión esencial; otras cosas se dejan administrables y desactivadas.

## Pendientes para una fidelidad visual 100% exacta

Los respaldos no incluyen capturas de todas las páginas ni export `wp_template` / `wp_template_part` / `wp_navigation` / `wp_block` ni opciones completas del FSE. Además, la web pública actual responde irregularmente; por tanto no se debe garantizar que una maqueta nueva sea idéntica píxel a píxel. Ver `09_DATOS_PENDIENTES_Y_SQL.md` para extracción complementaria de solo lectura. Sí hay fotografías corporativas, logo, estructura y textos de portada suficientes para iniciar desarrollo.
