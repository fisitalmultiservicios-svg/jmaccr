# 04 · Arquitectura, modelo de datos, integraciones y API

## 1. Arquitectura propuesta para hosting compartido

**Stack recomendado** (verificar compatibilidad real del hosting antes de instalar): PHP 8.3, Laravel en versión estable compatible, Blade server-side rendering, Alpine.js/JavaScript progresivo, CSS con utilidades compilado mediante Vite local/CI, MySQL 8/MariaDB compatible, almacenamiento privado para documentos y carpeta pública solo para archivos generados. Panel con componentes admin PHP/Blade o Filament compatible, pero **constructor visual propio** con bloques validados, sin WordPress. Composer/npm se usan en CI/desarrollo, no exigen procesos Node permanentes en cPanel.

Alternativa si hosting no permite framework pesado: PHP 8.3 limpio/CodeIgniter 4 con router y servicios equivalentes, documentando diferencias antes de elegir. No dividir el proyecto en frontend SPA + API remota si requiere Node persistente. Evitar microservicios/Redis/Supervisor obligatorios en plan compartido. Redis es opcional; drivers database/file permitidos según carga. SSR facilita SEO/velocidad en alojamientos modestos.

### Estructura sugerida

```text
jmac-app/                  (fuera del directorio web)
  app/
    Domain/{Cms,Catalog,Preorders,Contacts,News,Media,Auth}/
    Http/Controllers/{Public,Admin,Api}/
    Policies/
    Jobs/
  bootstrap/
  config/
  database/{migrations,seeders,factories}/
  resources/{views,js,css}/
  routes/{web.php,api.php,console.php}/
  storage/{app/private,framework,logs}/
  tests/{Feature,Unit,Browser}/
  vendor/
  .env                 (nunca público)
  public/               (ÚNICO document root)
    index.php
    build/
    storage/            (solo si se necesita y se controla)
```

No crear `wp-content`, `wp-admin`, `wp-includes` ni dependencias a base WordPress. Cualquier plugin o script del servidor anterior queda fuera.

## 2. Modelo lógico de BD y campos clave

Diseñar migraciones reales con FK, unique, índices, reglas `ON DELETE` cuidadosas, timestamps, revisiones y snapshots.

| Tabla | Campos/relaciones principales | Regla |
|---|---|---|
| `users` | id, name, email unique, password_hash, mfa_secret encrypted, status, last_login | Nunca migrar usuarios WordPress |
| `roles`, `permissions`, `role_permissions`, `user_roles` | control RBAC | Políticas en servidor |
| `site_settings` | key unique, json_value, scope, updated_by | Secretos cifrados, no exponer API pública |
| `site_themes` | id, name, design_tokens JSON, status, revision | Publicar y revertir |
| `pages` | id, slug unique, title, template, status, seo_*, current_revision_id, published_at | Rutas legibles |
| `page_revisions` | page_id, blocks_json, revision, author_id, created_at | Inmutables, validación de esquemas |
| `nav_menus`, `nav_items` | menu_id, label, url/page_id, parent_id, position, visible | Sin ciclos; URLs seguras |
| `media` | disk, path, mime, bytes, width, height, alt, checksum, uploaded_by, status | Solo media permitida |
| `categories` | id, parent_id, name, slug unique, summary, cover_media_id, position, status | **CERO** registros iniciales |
| `brands` | id, name, slug unique, logo_media_id, status | **CERO** registros iniciales |
| `products` | id, sku unique nullable en borrador, name, slug unique, description, category_primary_id, brand_id, status, unit, is_featured, position | **CERO** registros iniciales |
| `category_product` | category_id, product_id | Cardinalidad N:M si se permite |
| `product_media` | product_id, media_id, position, is_primary | Galería ordenada |
| `product_attributes` | product_id, name, value, unit, position | Características dinámicas |
| `preorders` | id, year, seq, public_code unique, customer_name/phone/email/company, observations, status, assigned_to, idempotency_key unique, created_at | **CERO** registros iniciales |
| `preorder_items` | preorder_id, product_id nullable, sku_snapshot, name_snapshot, unit_snapshot, quantity, metadata_snapshot | No alterar registro histórico por edición producto |
| `preorder_events` | preorder_id, actor_id nullable, from_status, to_status, note, created_at | Historial inmutable |
| `contact_submissions` | name, phone, email, company, message, status, consent_version, created_at | Proteger PII |
| `posts` | slug, title, excerpt, body_json/html sanitizado, status, featured_media_id, published_at | Noticias inicialmente cero |
| `post_revisions`, `post_categories`, `post_category_links` | cambios y clasificación | Versionado y filtros |
| `notifications_outbox` | event_type, aggregate_id, recipient, channel, payload_json, status, retries, next_retry_at, error_code | Separación DB vs entrega externa |
| `redirects` | old_path unique, target_path, status_code, enabled | Solo rutas aprobadas; evitar open redirects |
| `audit_logs` | actor_id, resource, id, action, before/after JSON redacted, ip_hash, created_at | Acceso restringido |
| `import_batches`, `import_errors` | import_id, actor, mapping, status, counts, safe_error | **Sin** importar catálogo heredado |
| `sequences` | sequence_name, year, next_number | Concurrencia y consecutivo sin duplicar |

Se pueden combinar algunas tablas por simplicidad, pero no suprimir control de revisiones, permisos, correlación e idempotencia. **Prueba automática tras `migrate:fresh --seed`: categorías 0, marcas 0, productos 0, contactos 0, preventas 0, posts 0**. Los únicos seeds permitidos son configuración base, roles y textos corporativos como borrador pendiente de aprobación. El superadmin inicial se crea mediante comando/instalador seguro con secreto entregado por canal privado o enlace de invitación de un solo uso.

### Índices mínimos

- `products (status, name)`, `products.sku UNIQUE`, `products.slug UNIQUE`, `categories.slug UNIQUE`, `brands.slug UNIQUE`.
- Si hay fulltext/collation disponibles, `FULLTEXT(name, description)` o servicio SQL equivalente; conservar búsqueda por SKU por `=`/prefijo.
- `preorders (status, created_at)`, `preorders (assigned_to, created_at)`, `preorders.public_code UNIQUE`, `preorders.idempotency_key UNIQUE`.
- `preorder_items (preorder_id)`, `contact_submissions (status, created_at)`, `notifications_outbox(status, next_retry_at)`.
- `posts (status, published_at)`, `audit_logs (resource, resource_id, created_at)`.

## 3. Operación crítica de preventa: idempotente y transaccional

**NO confiar en el carrito enviado por el navegador** para precios, nombres, SKU ni disponibilidad. Flujo:

```text
POST /api/preorders
  validar CSRF o auth de sesión / origen + rate limit + honeypot
  validar nombre, teléfono y consentimiento
  validar token idempotente de un solo intento lógico
  iniciar transacción
     ¿existe token? -> devolver resultado previo (sin duplicar)
     cargar por ID todos productos publicados
     rechazar ítems inexistentes, ocultos o cantidades inválidas
     tomar snapshot inmutable de SKU, nombre, unidad, cantidad
     bloquear fila secuencia (SELECT FOR UPDATE)
     reservar consecutivo único del año
     insertar preorders y preorder_items
     insertar evento 'recibida'
     insertar evento de notificación en outbox
  COMMIT
  devolver HTTP 201 o 200 idempotente con `JMAC-PV-AAAA-NNNNN`
  procesar outbox después del COMMIT mediante cron/job
```

Reintentos de red/recarga con el mismo token retornan el mismo número. Si SMTP cae, solicitud permanece `recibida` y notificación `failed`, no se confunde con una compra completada. Las notas de vendedor se controlan por roles.

## 4. Contrato de rutas (servidor y cliente)

| Método | Endpoint | Auth / propósito |
|---|---|---|
| GET | `/` | Public home SSR |
| GET | `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/` | Public, caché apropiada |
| GET | `/catalogo/?jmac_cat={slug}` | Public, compatibilidad histórica |
| GET | `/catalogo/{slug}/` | Public, ficha si publicada |
| GET | `/api/catalog/search?q=...&category=...&page=...` | Public, límites y paginación |
| POST | `/api/preorders` | Public, session/CSRF/antispam, idempotency key |
| POST | `/api/contacts` | Public, session/CSRF/antispam |
| GET | `/admin` | Auth + 2FA según rol |
| GET/POST/PUT | `/admin/pages...` | RBAC contenido |
| POST | `/admin/pages/{id}/publish` | RBAC publish + revision |
| POST | `/admin/theme/publish` | RBAC diseño + confirmación |
| GET/POST/PUT | `/admin/catalog/categories...` | RBAC catalog |
| GET/POST/PUT | `/admin/catalog/brands...` | RBAC catalog |
| GET/POST/PUT | `/admin/catalog/products...` | RBAC catalog |
| GET/PUT | `/admin/preorders...` | RBAC ventas |
| GET/PUT | `/admin/contacts...` | RBAC contactos |
| GET/POST/PUT | `/admin/posts...` | RBAC novedades |
| POST | `/admin/media/upload` | Auth/MIME/limites |
| POST | `/admin/system/cache-clear` | Superadmin + CSRF + audit |
| GET | `/sitemap.xml` y `/robots.txt` | Solo información pública aprobada |
| GET | `/admin/preview/{id}?token=...` | Sesión/token breve, noindex |

Los paths son un contrato lógico propuesto, no obligación de REST exacto; Laravel controllers pueden usar resource names bajo auth. Nunca dejar `/admin` accesible sin autenticación. En producción desactivar debug, no rutas `install` ni test con secretos en parámetros.

### Payloads de ejemplo

```json
{
  "idempotency_key": "UUID-generado-por-la-aplicacion",
  "customer": {"name": "Cliente ejemplo", "phone": "+50688888888", "company": "", "email": ""},
  "items": [{"product_id": 125, "quantity": 2}],
  "notes": "Necesito cotizacion",
  "privacy_accepted": true
}
```

**Es solo un ejemplo de contrato para cuando exista producto 125**; el catálogo real se instala sin productos y este payload debe rechazarse hasta que tal ID exista publicado.

## 5. Editor visual y bloques JSON

Guardar `blocks_json` solo con tipos autorizados. Ejemplo:

```json
{
  "schema_version": 1,
  "blocks": [
    {
      "id": "hero-home-jmac",
      "type": "hero",
      "data": {"headline": "UN PRODUCTO CON 20 AÑOS DE EXPERIENCIA", "image_media_id": null,
                "cta": {"label": "Ver catalogo", "href": "/catalogo/"}},
      "style": {"variant": "split", "spacing": "lg", "theme_token": "primary"},
      "visibility": {"desktop": true, "tablet": true, "mobile": true}
    }
  ]
}
```

Al publicar, validar esquema y referencias de media, sanitizar rich text por allowlist, rechazar JS/iframe arbitrario, colocar imágenes mediante IDs (no URLs externas sin allowlist), renderizar con vistas Blade confiables. Edición del bloque no debe cambiar inmediatamente la vista pública antes de publicar una nueva revisión.

## 6. Caché y performance

SSR + consultas selectivas + eager loading controlado; base catálogo paginada (`12-24`/página configurable), búsqueda SQL indexada; respuesta JSON solo datos útiles. Cache de secciones públicas versionado y purga al publicar (no borrar archivos). Minificar assets, HTTP cache para imágenes versionadas, compresión gzip/Brotli cuando cPanel permita, medir TTFB, LCP, CLS, INP sobre staging. Registrar `slow queries`, tiempo respuesta y errores sin guardar contenido sensible.

## 7. Correo/WhatsApp

Correo por SMTP con TLS, credenciales cifradas en `.env` o vault local, sin test SMTP en cliente. `outbox` para reintentos. WhatsApp click-to-chat a número E.164 configurable; si se instala WhatsApp Cloud API, sólo integración oficial con token seguro y webhooks validados, jamás scrapeo/sesiones no oficiales. En interfaz indicar resultado real: `solicitud registrada`, `correo pendiente`, `notificación enviada/fallida`.

## 8. Internacionalización y SEO

Mensajes español CR; zona horaria `America/Costa_Rica`, UTC en almacenamiento donde sea útil; fecha formateada local. Uso de slugs Unicode transliterados `ñ` -> `n` con mapeos explícitos, canonical permanente y redirección 301 cuando un slug cambia. `robots.txt` restringir zonas admin; staging `noindex`; OG imágenes aprobadas. Proteger lista pública contra spam/reflected XSS.

## 9. Configuración para portabilidad

Usar variables `APP_ENV`, `APP_KEY`, `APP_URL`, `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `MAIL_*`, `CACHE_STORE`, `SESSION_DRIVER`, `QUEUE_CONNECTION`, `FILESYSTEM_DISK`, `SESSION_SECURE_COOKIE`, sin valores secretos entregados por ChatGPT. Respetar límites de memoria/upload PHP y cron reales del host. Ofrecer `diagnostics:check`, `setup:verify`, `backup:verify`, health check no público con datos sensibles.
