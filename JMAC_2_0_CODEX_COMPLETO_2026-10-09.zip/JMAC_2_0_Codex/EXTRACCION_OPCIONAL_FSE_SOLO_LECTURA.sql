-- OPCIONAL. Ejecutar en phpMyAdmin únicamente tras verificar el prefijo real de tablas.
-- No modifica datos. No ejecutar archivos PHP o scripts del WordPress actual.
-- Permite examinar personalizaciones de plantillas, partes, menús y bloques FSE.

SELECT ID, post_type, post_status, post_title, post_name, post_content,
       post_date, post_modified
FROM wpfd_posts
WHERE post_type IN ('wp_template', 'wp_template_part', 'wp_navigation', 'wp_block')
  AND post_status IN ('publish', 'draft', 'private')
ORDER BY post_type, post_name, ID;

-- Consultar solo nombres de opciones. Revisar manualmente antes de exportar valores.
SELECT option_name
FROM wpfd_options
WHERE option_name LIKE 'theme_mods_%'
   OR option_name LIKE 'wp_global_styles%'
   OR option_name LIKE 'ona_%'
ORDER BY option_name;
