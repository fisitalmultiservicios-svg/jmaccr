# JMAC 2.0 · Paquete definitivo de especificaciones para Codex

**Fecha:** 09/10/2026 | **Dominio de destino:** `jmaccr.com` | **Idioma:** español (Costa Rica) | **Zona horaria:** `America/Costa_Rica`

## Decisión contractual prioritaria

Construir un **sitio nuevo y un CMS propio sin WordPress**, hospedable en **cPanel con PHP/MySQL**, manteniendo **solo identidad, información y materiales corporativos legítimos**. El **catálogo, categorías, marcas, productos, clientes y preventas empiezan vacíos**: **prohibido importar el catálogo anterior**, incluso el CSV histórico de 52 productos de un informe previo. El historial anterior solo es referencia de funcionamiento, nunca datos para el nuevo sistema.

**No instalar, ejecutar, copiar ni reutilizar** ningún script PHP, `.htaccess`, plugin, tema o shortcode del WordPress comprometido. El archivo `themes/ona-architecture/functions.php` del respaldo presenta código ofuscado y capacidad de ejecución dinámica; no es una fuente segura para producción ni una base de código. Los recursos incluidos en `assets_limpios/` son únicamente fotografías/logotipo decodificados y re-guardados, **no** scripts del sitio heredado.

## Orden de lectura para Codex

1. `PROMPT_MAESTRO_CODEX.md` — instrucciones directas, prioridades, definición de terminado.
2. `01_AUDITORIA_Y_EVIDENCIA.md` — hechos probados de los cuatro adjuntos y de la web, límites de certeza, calidad de datos.
3. `02_CONTENIDO_IDENTIDAD_Y_FRONTEND.md` — contenido corporativo, jerarquías, pantallas y UI/responsive.
4. `03_REQUISITOS_ADMIN_Y_NEGOCIO.md` — editor visual, catálogo desde cero, carrito de preventa, contactos, noticias, reportes.
5. `04_ARQUITECTURA_DATOS_Y_API.md` — stack PHP, diseño BD, endpoints, reglas transaccionales, performance.
6. `05_SEGURIDAD_Y_PROTECCION.md` — no reutilizar recursos peligrosos, autenticación, revisión, trazabilidad.
7. `06_DESPLIEGUE_CPANEL_Y_OPERACION.md` — instalación, cron, backups, diagnóstico y puesta en producción.
8. `07_PRUEBAS_Y_ACEPTACION.md` — matriz de QA y criterios verificables.
9. `08_ROADMAP_Y_ENTREGABLES.md` — etapas y condiciones para avanzar.
10. `09_DATOS_PENDIENTES_Y_SQL.md` — contenido WP de bloques no incluido en CSV y consultas read-only opcionales.

### Entregables estructurados

- `SEMILLA_CORPORATIVA_BORRADOR.json`: textos corporativos recuperables y estructura como **borrador**, nunca publicación automática; `products=[]`, `categories=[]`, `brands=[]`.
- `CATALOGO_INICIAL_VACIO.csv`: plantilla de campos, **sin ninguna fila de producto**.
- `AUDITORIA_PAGINAS.csv`: inventario de 9 registros del CSV original con decisiones de inclusión/exclusión.
- `MANIFIESTO_IMAGENES.csv`: relación, origen, dimensión, uso sugerido, SHA256 de 10 imágenes sanitizadas.
- `assets_limpios/`: fotografías y logotipo re-guardados. Revisar derechos/autorización y validar ubicación antes de publicar.
- `REFERENCIAS_DISENO.jpg`: mosaico orientativo de la selección de imágenes, **no representa una captura exacta de la web**.
- `INFORME_CONSOLIDADO_JMAC_CODEX.pdf`: documento de consulta humana; los Markdown y archivos estructurados son la fuente técnica más completa.

## Material investigado

- `themes.zip`: 3.604 elementos; tema declarado por opciones `stylesheet=ona-architecture`, `template=ona`; varios temas adicionales instalados. El tema activo declarado **no demuestra** que sea el tema original anterior al compromiso.
- `uploads.zip`: 221 elementos, incluidos archivos corporativos en marzo y mayo 2026 y material ajeno en agosto/septiembre; esos últimos **no se incluyeron**.
- `wpfd_options.csv`: 8 opciones; `blogname=JMAC`, `blogdescription=LIDER EN EL MERCADO INDUSTRIAL`, `show_on_front=posts`, `stylesheet=ona-architecture`, `template=ona`.
- `wpfd_posts.csv`: 9 páginas registradas, pero **Nosotros, Contacto y Novedades tienen el cuerpo vacío**; Catálogo contiene un shortcode del plugin antiguo y HTML inyectado; Reportes JMAC contiene otro shortcode. No existe exportación de `wp_template`, `wp_template_part`, `wp_navigation`, `wp_block`, de las opciones completas ni de los posts de noticias.

## Normas importantes

- **Fidelidad de marca antes que reproducción del malware:** conservar logo, fotografías aprobadas, navegación y mensajes corporativos verificados. El sitio público actual es inconsistente; no usar respuestas ajenas como referencia.
- **No inventar hechos de JMAC:** teléfonos, redes, correos, dirección, misión/visión y contenido de Nosotros requieren validación del propietario.
- **No publicar simulaciones:** formularios, admin, preventa, notificaciones, búsqueda y gestión del catálogo deben funcionar realmente.
- **No exigir Node en producción:** si se usa Vite, generar recursos estáticos antes de subirlos.
- **No editar producción ni DNS sin aprobación:** trabajar primero en staging.
- **Los faltantes no bloquean desarrollo:** implementar módulos y estados vacíos; marcar la similitud visual exacta como “pendiente de validación” si no existe captura antigua fiable.

## Qué hacer primero en Codex

Abrir la carpeta raíz con todo este paquete. Copiar el contenido íntegro de `PROMPT_MAESTRO_CODEX.md` a Codex, pedir que audite el repositorio destino y que ejecute el Hito 0/1 con pruebas. Puede convertir esta documentación en épicas/issues y generar el repositorio limpio; **no debe pedir importación de productos**.
