# JMAC 2.0

## Expediente técnico completo para Codex

**Reconstrucción del sitio corporativo y administración visual sin WordPress**

**Versión:** 1.0 · **Levantamiento:** 9 de octubre de 2026 · **Objetivo:** instalación en cPanel

**Decisión principal:** preservar información e identidad corporativa legítima, crear TODO el catálogo desde cero. El catálogo nuevo empezará con cero categorías, cero marcas y cero productos.

**Fuentes examinadas:** `themes.zip`, `uploads.zip`, `wpfd_posts.csv`, `wpfd_options.csv` y referencias públicas. No se han realizado modificaciones al sitio existente ni al hosting.

**Advertencia de alcance:** Las páginas Nosotros, Contacto y Novedades no tienen cuerpo en el CSV aportado; la equivalencia visual exacta requiere aprobación del propietario y, de ser posible, una exportación complementaria de plantillas FSE. Ningún código ejecutable del WordPress anterior se reutilizará.

---


\newpage

# 01 · Auditoría de fuentes y grado de certeza

## 1. Propósito del levantamiento

Se analizaron cuatro respaldos aportados por el propietario y versiones públicas indexadas de `jmaccr.com`. El fin es reconstruir el sitio empresarial, **no** recuperar WordPress ni migrar inventario. Diferenciar cada dato como `confirmado local`, `confirmado en fuente histórica pública`, `inferencia`, `pendiente de aprobación` o `excluido`.

## 2. Resumen de los archivos examinados

| Fuente | Resultado concreto | Uso permitido |
|---|---|---|
| `wpfd_options.csv` | 8 filas. `blogname=JMAC`; `blogdescription=LIDER EN EL MERCADO INDUSTRIAL`; `stylesheet=ona-architecture`, `template=ona` | Reconocer nombre/eslogan; tema solo como indicio |
| `wpfd_posts.csv` | 9 páginas: `Catálogo`, `Contacto`, `Nosotros`, `Novedades`, `Reportes JMAC`, `Privacy Policy`, `Sample Page`, dos registros extraños | Extraer exclusivamente estructura nominal legítima; no migrar HTML sin limpiar |
| `themes.zip` | Tema padre `ona`, hijo `ona-architecture`, otros temas instalados; child `theme.json` incluye paleta base de plantilla y tipografías Urbanist/Inter | Metadatos orientativos, **nunca ejecutar/copiarlos** |
| `uploads.zip` | Material corporativo identificable (2026/03, 2026/05) y numerosos ficheros ajenos posteriores; también ZIP internos | Selección aprobable re-codificada en `assets_limpios/` |
| Resultados públicos indexados | Rutas, texto de portada, formulario, catálogo/categorías y carrito observables | Referencia para interacción y copy, sujeta a aprobación |

Se revisó el ZIP sin ejecutar scripts ni extraer contenidos ejecutables a un sitio en funcionamiento. Las imágenes del paquete fueron decodificadas con un procesador de imágenes y almacenadas de nuevo como PNG/JPEG, sin preservar código, archivos ocultos ni ZIP del origen. Ello reduce riesgos de trasladar artefactos ocultos, pero no sustituye revisión humana de la procedencia y los derechos de uso.

## 3. Resultado de `wpfd_posts.csv` (9 registros)

| ID | Página | Slug | Estado | Lectura exacta | Decisión |
|---|---|---|---|---|---|
| 6 | Catálogo | `catalogo` | publish | `[jmac_catalogo]` y un fragmento HTML ajeno/incrustado | Preservar ruta; **NO** copiar shortcode ni HTML |
| 1287 | Contacto | `contacto` | publish | `post_content` vacío | Crear estructura; contenido detallado pendiente |
| 1276 | Nosotros | `nosotros` | publish | `post_content` vacío | Crear estructura; contenido detallado pendiente |
| 1282 | Novedades | `novedades` | publish | `post_content` vacío | Crear estructura; noticias sin migrar |
| 4186 | Reportes JMAC | `reportes-jmac` | publish | `[jmac_reportes_portal]` | Posible función administrativa antigua; **alcance pendiente**, no exponer público ni copiar |
| 3 | Privacy Policy | `privacy-policy` | draft | Texto de ejemplo WordPress | No migrar; redactar política legal propia, aprobada |
| 2 | Sample Page | `sample-page` | publish | Página de ejemplo WP | No migrar |
| 11164 | Página no corporativa | slug extraño | publish | Contenido de apuestas ajeno al negocio | Rechazar |
| 11162 | tag | `tag` | draft | Vacía/no corporativa | Rechazar |

**Precisión crítica:** que una página tenga `post_content` vacío no significa necesariamente que careciera de contenido visual en WordPress. El sitio usa tema **Full Site Editing**; partes de su diseño pueden residir en `wp_template`, `wp_template_part`, `wp_navigation`, `wp_block` o personalizaciones de base de datos **no incluidas** en la exportación. Así, **no podemos asegurar una réplica visual píxel a píxel con estos archivos solamente**. Construir una aproximación fiel editable y registrar las diferencias pendientes de aprobación.

`show_on_front=posts` sugiere que en el momento del export WordPress mostraba el índice de entradas como inicio, pero puede reflejar configuración alterada; **no invalida** la portada corporativa que figuraba en vistas históricas.

## 4. Tema y colores

El par activo declarado: `Ona Architecture` (hijo) y `Ona` (padre). El child `theme.json` declara, entre otros, `#191919` texto, blanco `#ffffff`, `#e54d1e` primario, y tipografías Urbanist/Inter. **Es una configuración de plantilla arquitectónica, no evidencia de colores definitivos de JMAC.** El logotipo corporativo sí contiene azul/blanco y sugiere una paleta azul, blanco y neutros; los valores de `SEMILLA_CORPORATIVA_BORRADOR.json` son **propuestas de diseño**, no un pantone histórico validado.

El archivo `themes/ona-architecture/functions.php` mide aproximadamente 225 KiB, inicia con condicionales basados en cookies, decodificación de datos y carga dinámica de código, además de una larga sección ofuscada. Es **incompatible con un fuente confiable de personalización**. Ningún archivo PHP o `.htaccess` de ese respaldo forma parte de la entrega segura. No deducir autores ni mecanismo exacto sin análisis forense, que queda fuera del alcance.

## 5. Imágenes recuperables

`assets_limpios/` contiene 10 elementos aprobables: un logotipo, fotografías corporativas de escritorio/productos y personal, fondos industriales y el banner con texto incrustado. El listado de procedencia está en `MANIFIESTO_IMAGENES.csv`. Todos requieren verificación visual del propietario antes de publicar. Algunas imágenes casi idénticas son variantes de recorte; seleccionar una por sección para evitar descargas redundantes.

**No se incluyen**: imágenes de apuestas y otros contenidos ajenos, material procedente de 2026/08 o 2026/09, ZIP incluidos en uploads, `Screenshot_3.png` (POS ajeno), archivos ejecutables, CSS/JS/PHP de temas ni fuentes tipográficas binarias. Si Codex necesita tipografías web, debe usar un origen seguro y cumplir la licencia correspondiente; no transferir los archivos fuente antiguos como parte del paquete.

## 6. Portada y estructura pública histórica

Copia corporativa visible en versiones indexadas:

- **JMAC — LIDER EN EL MERCADO INDUSTRIAL** (también en `wpfd_options.csv`).
- “UN PRODUCTO CON 20 AÑOS DE EXPERIENCIA”.
- “Somos líderes gracias a la confianza que cada uno de nuestros clientes nos brinda día a día.”
- “ORGULLOSAMENTE TICOS”.
- “Unión de Experiencia, Tecnología y Calidad”.
- “Nuestra propuesta de producto siempre se ha basado en la experiencia adquirida en la venta de productos de línea industrial por más de dos décadas.”

Una imagen del respaldo incluye visualmente la variante **“Un producto creado con 20 años de experiencia”**. Es una diferencia de redacción entre materiales: consultar al propietario cuál usar y preferir texto HTML editable en vez de rasterizado al publicar.

Rutas/menú históricos: `/`, `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/`, junto con referencias a `Inicio`, `Nosotros`, `Contáctanos`, `Novedades`, `Catálogo`.

## 7. Funciones del catálogo anterior (solo referencia de UX)

Históricamente se observaron seis categorías: `ADITIVOS`, `CADENAS`, `MUÑONERAS`, `OTROS`, `PIÑONES`, `ROLES`; buscador por nombre/código; botones “Cargar al carrito”; contador; preventa con nombre/teléfono/empresa. **NO precargar estas categorías ni un solo producto.** El propietario decidió reconstruir su inventario desde cero en el nuevo CMS. Implementar compatible el comportamiento general del selector de categorías a medida que se creen registros nuevos; la nueva página inicial de catálogo deberá mostrar un estado vacío bien diseñado (sin mensajes de error).

## 8. Navegación web inconsistente

Algunas versiones públicas indexadas siguen mostrando JMAC, mientras accesos actuales a las mismas rutas devuelven comercios ajenos. Este estado **impide confiar en la web actual como fuente para capturas visuales exactas**, redirecciones, precios o contenido comercial. Nunca copiar imágenes/productos ajenos ni HTML servido actualmente sin contraste con material verificado. En este informe no se repite contenido promocional ajeno al negocio.

## 9. Inventario de evidencias web para auditoría humana

- Sitio y portada histórica: https://jmaccr.com/
- Acerca de: https://jmaccr.com/nosotros/
- Contacto: https://jmaccr.com/contacto/
- Novedades: https://jmaccr.com/novedades/
- Catálogo: https://jmaccr.com/catalogo/

Estas URL pueden ofrecer contenido errático. Priorizar los archivos aportados y material gráfico aprobado por JMAC. No ligar enlaces a medios de terceros que no sean del negocio.

## 10. Matriz de confianza para implementación

| Elemento | Estado | Conducta de Codex |
|---|---|---|
| Nombre y eslogan | Confirmado en CSV | Borrador precargado |
| Logo J-MAC for the industry | Identificable en archivo gráfico | Importar como candidato con aprobación |
| Fotos 2026/03 y 2026/05 | Visualmente corporativas | Incluir como candidatos; no asumir estructura exacta |
| Copy portada | Referencia histórica pública | Crear bloque editable con aprobación de versión |
| Navegación cinco rutas | Coincide con evidencia pública y CSV | Implementar |
| Formulario nombre/teléfono/correo | Evidencia pública | Implementar; añadir mensaje/consentimiento como propuesta |
| Contenido completo Nosotros | **No recuperado** | No inventar; editor vacío y publicación controlada |
| Entradas de Novedades | **No exportadas** | Noticias empiezan vacías |
| Características anteriores catálogo | Históricas, parciales | Usar solo como patrón funcional |
| Productos, categorías, marcas, precios | Decisión explícita: cero | Tablas y seed **vacíos** |
| Portal Reportes JMAC | Shortcode encontrado; alcance desconocido | No reconstruir como página pública, pedir definición aparte |
| Identidad cromática exacta/maquetación WP | No verificable | Prototipo aprobable y diseño ajustable |
| Contactos oficiales, redes, domicilio | No verificados | Dejar sin configurar, no inventar |


\newpage

# 02 · Especificación detallada de contenido, identidad y frontend público

## 1. Objetivo editorial y gráfico

Reproducir la imagen corporativa **J-MAC for the Industry** usando material recuperado y aprobado, con acabado empresarial, industrial y profesional. El nuevo frontend debe mostrar contenido HTML semántico (no títulos embebidos únicamente en imágenes), funcionar rápido, ser accesible y verse correctamente en escritorio, tablet y móvil. No presentar WordPress, plantillas Ona ni su menú en el código final. Los colores definitivos se deciden desde el editor de marca y se aprueban en staging.

## 2. Estructura de navegación

| Ruta obligatoria | Objetivo | Estado inicial | Bloques clave |
|---|---|---|---|
| `/` | Portada corporativa | Borrador con texto candidato | Hero, valores, fotografías, CTA catálogo, secciones |
| `/nosotros/` | Perfil JMAC | Borrador vacío o mínimamente identificado | Intro, historia, misión/visión solo si se facilitan, galería, CTA |
| `/contacto/` | Captación de consultas | Lista cuando se configuren canales | Texto, formulario, contacto, mapa opcional, WhatsApp |
| `/novedades/` | Noticias corporativas | 0 publicaciones | Listado, filtros, paginación, detalle |
| `/catalogo/` | Catálogo editable desde cero | 0 categorías / 0 productos | Categorías, buscador, filtros, carrito de preventa |
| `/novedades/{slug}/` | Detalle de noticia | Al publicar | Artículo, metadatos, imagen, CTA |
| `/catalogo/{slug}/` | Detalle de producto opcional | Al cargar productos | Ficha, características, imágenes, agregar a preventa |
| `/politica-de-privacidad/` | Información legal propia | Pendiente de texto legal aprobado | Documento versionado |

`/reportes-jmac/` no se recreará por defecto. El shortcode histórico `[jmac_reportes_portal]` no revela su lógica. Si el propietario confirma necesidad de reportes, diseñar un módulo interno **nuevo** protegido por roles, nunca reconstruir accesos antiguos sin validación.

Encabezado global: logotipo, menú configurable `Inicio`, `Nosotros`, `Contáctanos`, `Novedades`, `Catálogo`; CTA opcional. Header sticky configurable con logotipo responsivo. Menú móvil accesible por teclado, botón con `aria-expanded`, overlay apropiado y foco visible. Los vínculos deben ser reales y conservar slugs históricos.

Pie: JMAC/eslogan, datos reales de contacto parametrizados, enlaces de redes si se configuran, créditos y aviso legal. Crédito “Desarrollado por Fisital” opcional y editable, nunca una dependencia a servicios externos.

## 3. Contenido conocido de Inicio `/`

Orden de bloques recomendado, editable en su totalidad:

1. **Hero grande**: imagen de ambiente de trabajo corporativo `portada-fotografia.jpg` (o `portada-banner-con-texto.jpg` solo como referencia), título **“UN PRODUCTO CON 20 AÑOS DE EXPERIENCIA”**, subtítulo **“Somos líderes gracias a la confianza que cada uno de nuestros clientes nos brinda día a día.”** Botón “Ver catálogo”, opcional “Conócenos”.
2. **Declaración de origen**: título “ORGULLOSAMENTE TICOS”, imagen corporativa opcional `orgullosamente-ticos.jpg`, texto complementario sujeto a aprobación.
3. **Experiencia, tecnología y calidad**: título “Unión de Experiencia, Tecnología y Calidad”, texto aprobado candidato “Nuestra propuesta de producto siempre se ha basado en la experiencia adquirida en la venta de productos de línea industrial por más de dos décadas.”, foto de ambiente industrial `produccion-industrial.jpg` o `corporativa-producto.jpg`.
4. **Acceso al catálogo**: bloque de categorías **dinámico**. Si no hay categorías aprobadas, mostrar CTA “Próximamente” configurable o esconder sección, sin botones falsos ni productos de relleno.
5. **CTA de contacto**: encabezado sencillo, botones a formulario/WhatsApp (WhatsApp oculto mientras no exista número validado).
6. **Novedades recientes**: últimas 3 publicadas; ocultar automáticamente si no existen.

No copiar los textos como una única imagen: H1, subtítulos y CTAs deben ser seleccionables, editables y legibles con tecnologías de asistencia. Si se usa el banner original con título sobreimpreso, crear alternativa accesible, evitar duplicar el texto visual y pedir aprobación.

## 4. Nosotros `/nosotros/`

El CSV registra la página, pero `post_content` está vacío. Debe crearse una página de diseño empresarial con los siguientes bloques **vacíos/editables**: hero/banner, presentación, historia, valores, experiencia, personas/fotos y CTA a contacto. **No inventar** fundador, fechas exactas, misión/visión, ubicación, distribución, certificaciones, cobertura ni números de clientes. No trasplantar textos de `jumacindustrial.com` aunque la marca aparezca vinculada en buscadores; JMAC y Jumac Industrial son entidades/marcas que requieren aprobación de relación jurídica y editorial.

Se puede proponer usar `corporativa-retrato.jpg` solo con autorización de la persona fotografiada. Otros recursos: `corporativa-producto.jpg`, `produccion-industrial.jpg`. Se recomienda alta calidad original y versiones WebP/AVIF generadas por el nuevo CMS.

## 5. Contacto `/contacto/`

Formulario de referencia pública con `Nombre completo`, `Teléfono`, `Correo electrónico`, botón `Enviar Mensaje` y WhatsApp. Nueva versión propuesta: campo `Mensaje` (requerido), `Empresa` (opcional), checkbox de consentimiento si corresponde a la política aprobada, honeypot antispam y alerta de privacidad. Validar longitud y formato tanto en servidor como navegador. Registrar cada consulta en DB, mostrar comprobante y enviar correo si está configurado. Nunca borrar consulta por fallo de correo.

Datos del negocio configurables desde Admin > Configuración > Empresa: nombre comercial, teléfonos, WhatsApp E.164, email destino, email público, dirección, horarios, enlaces Maps, Facebook, Instagram y otras redes. **Todo vacío salvo JMAC y eslogan**. Maps embebido es opcional y debe respetar preferencias de privacidad/cookies cuando aplique.

## 6. Novedades `/novedades/`

Listado de artículos exclusivamente nuevos: estado editorial, fecha publicación, título, extracto, miniatura, autor opcional, categoría, tags, filtros y paginación. Ficha SEO y botones para compartir opcionales. No se transfieren antiguas entradas ni noticias externas; la exportación aportada no contiene el post type `post`. La ausencia de noticias se maneja con vista vacía corporativa.

## 7. Catálogo `/catalogo/` nuevo

El frontend mantiene el concepto: categorías clicables, búsqueda por código/nombre, fichas de producto, fotos, botón **“Cargar al carrito”**, contador y **“Carrito de preventa”**. El catálogo inicialmente **no contiene** nada. El administrador tendrá que crear desde cero categorías, marcas y productos. Al no haber resultados, mostrar el encabezado/imagen corporativa y un estado vacío administrable: “Estamos actualizando nuestro catálogo. Contáctanos para consultar disponibilidad.” (texto **propuesto**, editable y no obligatorio).

### Comportamientos al cargar productos

- Categorías con imagen, título, orden de aparición y número de productos publicados.
- Búsqueda accent-insensitive por nombre, código/SKU y palabras clave, con debounce y paginación; sanitizar entradas.
- Filtros dinámicos por categorías/marcas/atributos disponibles; no mostrar filtros sin opciones.
- Cada producto: nombre, SKU, imágenes, breve descripción, CTA “Cargar al carrito”, ficha opcional con atributos técnicos, documento PDF descargable si autorizado.
- Sin precios ni pagos por defecto. Valores internos o cotizables pueden existir para futuro, pero **ocultos al público** salvo autorización expresa.
- Cantidad mínima 1, límite configurable, la suma/quita actualiza contador, mantener carrito del visitante por sesión local y validar cada línea en servidor al enviar.
- No permitir confirmar un producto despublicado; explicar al usuario si un ítem dejó de estar disponible.
- Persistir catálogo en base de datos y crear URL slug solo al guardar producto. Nunca importar registros históricos.
- Compatibilidad SEO con enlaces de categoría existentes `?jmac_cat=...`: mapear el slug con categorías nuevas si fueron creadas con ese slug. Si no existen, mostrar listado vacío, no 500/404 injustificado.

### Carrito de preventa

Campos: Nombre (obligatorio), Teléfono (obligatorio), Empresa (opcional), Email (opcional), Observaciones (opcional), detalle de líneas/cantidades, aviso de privacidad. CTA `Pre venta` o `Solicitar preventa` administrable. **No es checkout de pago**. Mostrar consecutivo al confirmar si DB guardó la solicitud; estados: recibido / en revisión / cotizado / gestionado / cerrado / cancelado. Notificar por email/WhatsApp según integración que exista; mensaje prellenado de WhatsApp solo abre aplicación y no prueba entrega. El registro en DB prevalece.

## 8. Diseño: sistema flexible sin desarrollador

Implementar tokens globales `--color-primary`, `--color-secondary`, `--color-text`, `--color-background`, `--color-muted`, `--radius-*`, `--space-*`, tamaños de heading, ancho de contenido, estilo botones y tipografías. Editor de escritorio/tablet/móvil para cambios de sección, con vistas previas y publicación separada de borrador. Permitir reemplazar imágenes, mover bloques, ajustar alineación/tamaño, fondo, texto, botones y visibilidad por página y breakpoint. Limitar opciones a composiciones compatibles para evitar rotura visual; no ofrecer inserción de JS/PHP arbitrario.

Colores preliminares basados en el logo azul/blanco, guardados como *propuesta*: azul principal `#174B91`, celeste secundario `#1C87BB`, tinta `#18263D`, blanco `#FFFFFF`. Estos **no** son colores auditados del sitio histórico. Las configuraciones de `Ona Architecture` incluyen un naranja genérico que no debe imponerse.

## 9. Diseño responsivo, accesibilidad y rendimiento

- Puntos de prueba: 360, 390, 768, 1024 y 1440 px; soporte de zoom 200%; control táctil mínimo 44 x 44 CSS px recomendado.
- HTML5 semántico, un único H1 visible por vista; jerarquía H2/H3, etiquetas explícitas, `alt` descriptivo, foco visible, contraste WCAG AA en texto funcional, navegación por teclado.
- Usar `loading="lazy"` para imágenes no visibles y carga prioritaria en LCP; `srcset`/`sizes`, formatos comprimidos; ningún asset original de 10–30 MB en homepage.
- CSS/JS compilados versionados y minificados; SSR Blade; cache HTTP controlado; no cargar todas las imágenes ni productos a la vez.
- Cookies esenciales de sesión/CSRF seguras; opcionales de analítica solo tras consentimiento cuando aplique.
- SEO: títulos y descripciones por página, canonical, Open Graph/Twitter, JSON-LD Organization/LocalBusiness solo con datos confirmados, productos sin precios inventados, robots, sitemap únicamente publicadas, redirecciones 301 si cambian slugs aprobados.
- Escribir textos en español de Costa Rica y formatos `₡` cuando eventualmente haya importes aprobados. Zona horaria `America/Costa_Rica`.

## 10. Referencia visual

El archivo `REFERENCIAS_DISENO.jpg` es una composición de la selección de imágenes de origen; **NO** una captura de toda la web. El archivo `MANIFIESTO_IMAGENES.csv` sirve para reconstruir a partir de piezas gráficas. Para aprobación visual final, solicitar capturas originales de una versión limpia o recibir aprobación expresa sobre la nueva maqueta. Nunca atribuir coincidencia exacta basándose solo en la temática de imágenes.


\newpage

# 03 · Backend administrativo integral, procesos y permisos

## 1. Principios del panel `/admin`

Panel propio **en español**, profesional, rápido en cPanel, centrado en propietarios no programadores. Menú lateral agrupado, buscador global administrativo, inicio claro, formularios con guardado/borrador, confirmación de cambios destructivos, avisos de éxito/fracaso, previsualización y soporte móvil. Todos los controles deben ser funcionales y conectados a BD.

**Estructura del menú propuesta:**

1. Inicio / estadísticas.
2. **Sitio web**: páginas, constructor visual, menús, encabezado y pie, banners, diseño global, multimedia.
3. **Catálogo**: categorías, subcategorías, marcas, productos, atributos, unidades, publicaciones, import/export **futuro**.
4. **Solicitudes**: preventas, contactos, seguimiento, plantillas de respuesta, notificaciones.
5. **Comunicación**: Novedades, enlaces y redes, formularios.
6. **SEO**: metadatos, redirecciones, sitemap, URL/robots.
7. **Sistema**: empresa, SMTP/canales, usuarios y permisos, auditoría, caché, salud, backups.

### Roles obligatorios

- `superadmin`: configuración y todos los accesos, 2FA obligatoria.
- `administrador`: contenido, catálogo, solicitudes y diseño, sin administrar secretos críticos salvo permiso explícito.
- `editor_web`: páginas, menús, diseño limitado, blog y medios; no ve datos personales de clientes por defecto.
- `gestor_catalogo`: categorías, marcas, productos, imágenes, fichas y estado publicado.
- `ventas`: ve/gestiona preventas y mensajes, no modifica diseño ni usuarios.
- `consulta`: solo lectura de funciones asignadas.

Permisos granulares en servidor: `pages.view/create/update/publish`, `theme.update`, `products.*`, `preorders.view/assign/update/export`, `contacts.*`, `settings.sensitive`, `users.manage`, `backups.restore`, etc. No confiar solo en esconder menús. Acciones masivas requieren permisos y confirmación.

## 2. CMS visual sin WordPress

### Requisitos de páginas

CRUD de páginas con título, ruta/slug único, plantilla, SEO, estado borrador/publicado/programado/archivado, identidad del editor y timestamps. Constructor de bloques permitidos, con arrastrar/reordenar, duplicar, ocultar, eliminar, edición inline de texto, selector multimedia, secciones reutilizables, controles de padding/columnas/espaciado/color por bloque, variante desktop/tablet/móvil. Vista previa protegida con token y/o sesión, accesible antes de publicar. Versionado por página y **restauración** de una revisión sin sobrescribir el historial.

### Biblioteca mínima de bloques

`hero`, `slider`, `heading`, `rich_text` seguro, `text_image`, `image`, `gallery`, `columns`, `icon_features` (iconos internos), `cta`, `buttons`, `testimonials` solo si aprobados, `contact_form`, `whatsapp`, `news_feed`, `catalog_categories`, `featured_products`, `spacer/divider`, `faq` opcional, `map` opcional. Esquemas JSON por tipo con reglas y valores por defecto; no permitir HTML arbitrario ni scripts. Añadir migraciones de esquema para evolución de bloques.

### Diseño global y componentes

Editor de colores, logo, favicon, fuentes, tamaños, fondos, enlaces, anchos, header/footer, CTA, estilos de tarjetas, variantes de nav y pie, mensaje de cookies, social sharing y enlaces externos. Tema visual versionado; publicación y rollback independientes. Mostrar comparativa antes/después. Evitar que editar colores bloquee accesibilidad: advertencias de contraste. Proveer un “Restablecer configuración visual” limitado a tokens, no borrar contenidos.

### Multimedia

Subida permitida: JPEG, PNG, WEBP, AVIF si servidor lo soporta y PDF verificado; MIME real, límite tamaño, nombre aleatorio, almacenamiento privado/seguro; redecodificación de imágenes para despojar metadatos y perfiles innecesarios, variantes retina y miniaturas, descripción y texto ALT. PDFs se servirán como descarga con encabezados, nunca ejecutar. No permitir `.php`, `.phtml`, SVG con scripts, `.htaccess`, ZIP ejecutables, contenido HTML ni archivos de scripts. Gestión de archivos no usados con comprobación de referencias antes de eliminar.

## 3. Catálogo completamente nuevo

**Regla innegociable**: en instalación limpia, `products=0`, `categories=0`, `brands=0`, `product_media=0`, `preorders=0` y `preorder_items=0`. No conservar inventario ni códigos viejos. No incluir “demo” visible. Las categorías históricas solo se mencionan en auditoría, **no se insertan**.

### Categorías

Nombre, slug único, descripción, categoría padre opcional, imagen, estado visible/oculta, orden. Permitir jerarquía y drag-sort, impedir ciclos padre-hijo, confirmación para eliminar categoría con productos, paginación y búsqueda. Contadores derivados, no fijos.

### Marcas

Nombre, slug único, logotipo, descripción, orden y estado. Puede iniciarse también con la marca J-MAC, **pero solo tras acción del administrador**. No precargarla automáticamente en la tabla `brands`.

### Productos

- Identificador interno, SKU/código **único** (requerido al publicar, opcional en borrador), título, slug, resumen, descripción larga con HTML permitido por sanitizer.
- Categoría(s), marca, etiquetas, unidad de medida, materiales, medidas, especificaciones técnicas estructuradas nombre/valor/unidad, variaciones opcionales, PDFs técnicos.
- Imágenes múltiples, portada, orden galería, ALT por foto, recorte responsivo.
- Status `draft`, `published`, `hidden`, `archived`, sort_order, destacado, stock opcional, `request_only` por defecto.
- Precio campo opcional privado (CRC) sin obligar usarlo; no publicarlo ni utilizar checkout/pago online sin solicitud posterior.
- Botones `Guardar borrador`, `Publicar`, `Vista previa`, `Duplicar`, `Despublicar`, `Archivar` y borrado reversible.
- Validaciones de código/slug, control de colisiones y transacciones, índices en búsquedas, ordenamiento y paginación.
- Importación CSV **como herramienta futura** para productos que el propietario suministre después; asistente mapping/preview/validación/errores y rollback por lote. **No ejecutar importación histórica como parte de la migración**.
- Exportación CSV/XLSX futura, solo usuarios autorizados, control de límites y protección contra CSV formula injection.

### Primera experiencia vacía

Público: portada sigue funcionando y catálogo presenta estado vacío administrable. Admin: CTA `Crear primera categoría`, `Crear primera marca`, `Agregar producto`; contar cero sin falsas métricas. Tests verifican que instalar no genera productos o categorías.

## 4. Preventas: proceso completo

**Dominio:** solicitud comercial, no compra pagada. El cliente arma una lista de ítems y envía datos; equipo de ventas revisa/contacta/cotiza fuera o dentro del módulo.

### Flujo público

1. Usuario entra al catálogo, filtra/busca.
2. Agrega ítems publicados con cantidad positiva, edita y remueve.
3. En carrito ve nombre/código/cantidad, y un formulario `Nombre`, `Teléfono`, `Empresa` (opcional), `Email` (opcional), `Observaciones` (opcional).
4. Valida consentimiento y antispam; envía petición HTTPS con token idempotente.
5. Backend valida cada ID contra publicaciones actuales, recrea snapshot de nombre/SKU/unidad, guarda en una transacción el consecutivo `JMAC-PV-AAAA-NNNNN` (formato configurable) y las líneas.
6. Tras commit, devuelve número y mensaje de recepción. Encola notificaciones con estado comprobable, no considera “enviada” si falla correo o API.
7. Panel administrativo muestra solicitud completa y timeline de cambios.

### Estados

`recibida -> en_revision -> cotizada -> gestionada -> cerrada`, con `cancelada` desde estados permitidos. No saltos arbitrarios sin privilegio. Registrar transición, fecha, usuario, nota; asignación de vendedor, etiquetas, filtros por fecha/estado/contacto, búsqueda por número/SKU. Mantener snapshot de datos de los productos si se borran o modifican posteriormente.

### Notificaciones

Correo SMTP a destinatarios configurados (plantilla HTML + texto), correo al cliente **solo si brinda email y autoriza**. WhatsApp: click-to-chat opcional (cliente inicia comunicación) o integración Business API oficial configurada por credenciales seguras; apertura de URL no es envío automático. Los logs deben registrar `pending/sent/failed` y reintentos limitados por cron. Evitar duplicados con clave idempotente y retriable outbox. Nunca exponer email/telef. en URL GET salvo click-to-chat consentido y controlado.

### Administración

Bandeja, detalle, cambio de estado, nota interna, asignación, filtros, exportar CSV/PDF, impresión A4 o térmica opcional futura, estadísticas de solicitudes por período, historial y alertas. Los formularios deben proteger datos personales; retención y borrado parametrizables.

## 5. Formularios de contacto

`contact_submissions` con nombre, teléfono, email, empresa, mensaje, estado, origen, fecha, consentimiento; con límites anti-spam/honeypot/reCAPTCHA opcional, listas de bloqueos y rate limit. Persistir primero, enviar correo después, nunca duplicar por recarga. Estados `nuevo`, `en_proceso`, `respondido`, `cerrado`, nota interna, responsable, búsqueda, descarga controlada y registro de borrado/anonymización.

## 6. Blog/Novedades

Crear/publicar/borrador, portada, editor WYSIWYG seguro, extracto, fecha, autora/o opcional, categorías/tags, SEO y OG, galería, vista previa, revisiones, programación (si cron soporta), comentarios **deshabilitados** salvo requerimiento explícito. Feed dinámico en Inicio solo si artículos publicados. **No importar antiguos posts** de la web comprometida.

## 7. Configuración, usuarios, herramientas y estadísticas

- `Datos empresa`: contactos, mapa, horario, razón social opcional, nombre, logo, redes, link WhatsApp validado.
- `Correos`: remitente, SMTP sin exponer contraseña tras guardado, envío de prueba autorizado, alertas de error.
- `SEO`: titles/descriptions, OG imagen, sitemap actualizado, robots, noindex de staging.
- `Usuarios`: invitar, activar/desactivar, MFA/2FA, restablecimiento seguro, roles; bitácora.
- `Diagnóstico`: versión app, PHP/extensiones, DB, cola/cron, espacio de disco, última copia verificada, last email failure, certificados de HTTPS si se consulta con seguridad.
- `Caché`: invalidación selectiva tras publicar y botón solo administradores; no borrar medios ni contenido al limpiar.
- `Respaldos`: instrucciones a nivel host y aplicación; backup automático programable si capacidades del hosting lo permiten; restauración solo Superadmin con doble confirmación.
- `Auditoría`: cada cambio de páginas, productos, diseño, preventas, permisos y configuraciones queda registrado; en cambios sensibles guardar diffs **sin secretos**.
- `Exportaciones`: estadísticas básicas, reporte por fecha/estado/categoría/producto una vez que existan datos; acceso controlado.

## 8. Operaciones del CMS que requieren aprobación

Nunca activar pasarela, publicar precios, importar catálogo viejo, migrar clientes, activar WhatsApp API, cambiar DNS, eliminar WordPress o reemplazar contenido en producción sin autorización explícita. Codex puede implementar estas capacidades como módulos optativos desactivados, pero no simular que ya están activas.


\newpage

# 04 · Arquitectura, modelo de datos, integraciones y API

## 1. Arquitectura propuesta para hosting compartido

**Stack recomendado** (verificar compatibilidad real del hosting antes de instalar): PHP 8.3, Laravel en versión estable compatible, Blade server-side rendering, Alpine.js/JavaScript progresivo, CSS con utilidades compilado mediante Vite local/CI, MySQL 8/MariaDB compatible, almacenamiento privado para documentos y carpeta pública solo para archivos generados. Panel con componentes admin PHP/Blade o Filament compatible, pero **constructor visual propio** con bloques validados, sin WordPress. Composer/npm se usan en CI/desarrollo, no exigen procesos Node permanentes en cPanel.

Alternativa si hosting no permite framework pesado: PHP 8.3 limpio/CodeIgniter 4 con router y servicios equivalentes, documentando diferencias antes de elegir. No dividir el proyecto en frontend SPA + API remota si requiere Node persistente. Evitar microservicios/Redis/Supervisor obligatorios en plan compartido. Redis es opcional; drivers database/file permitidos según carga. SSR facilita SEO/velocidad en alojamientos modestos.

### Estructura sugerida

```text
jmac-app/                  (fuera del directorio web)
  app/
    Domain/{Cms,Catalog,Preorders,Contacts,News,Media,Auth}/
    Http/Controllers/{Public,Admin,Api}/
    Policies/
    Jobs/
  bootstrap/
  config/
  database/{migrations,seeders,factories}/
  resources/{views,js,css}/
  routes/{web.php,api.php,console.php}/
  storage/{app/private,framework,logs}/
  tests/{Feature,Unit,Browser}/
  vendor/
  .env                 (nunca público)
  public/               (ÚNICO document root)
    index.php
    build/
    storage/            (solo si se necesita y se controla)
```

No crear `wp-content`, `wp-admin`, `wp-includes` ni dependencias a base WordPress. Cualquier plugin o script del servidor anterior queda fuera.

## 2. Modelo lógico de BD y campos clave

Diseñar migraciones reales con FK, unique, índices, reglas `ON DELETE` cuidadosas, timestamps, revisiones y snapshots.

| Tabla | Campos/relaciones principales | Regla |
|---|---|---|
| `users` | id, name, email unique, password_hash, mfa_secret encrypted, status, last_login | Nunca migrar usuarios WordPress |
| `roles`, `permissions`, `role_permissions`, `user_roles` | control RBAC | Políticas en servidor |
| `site_settings` | key unique, json_value, scope, updated_by | Secretos cifrados, no exponer API pública |
| `site_themes` | id, name, design_tokens JSON, status, revision | Publicar y revertir |
| `pages` | id, slug unique, title, template, status, seo_*, current_revision_id, published_at | Rutas legibles |
| `page_revisions` | page_id, blocks_json, revision, author_id, created_at | Inmutables, validación de esquemas |
| `nav_menus`, `nav_items` | menu_id, label, url/page_id, parent_id, position, visible | Sin ciclos; URLs seguras |
| `media` | disk, path, mime, bytes, width, height, alt, checksum, uploaded_by, status | Solo media permitida |
| `categories` | id, parent_id, name, slug unique, summary, cover_media_id, position, status | **CERO** registros iniciales |
| `brands` | id, name, slug unique, logo_media_id, status | **CERO** registros iniciales |
| `products` | id, sku unique nullable en borrador, name, slug unique, description, category_primary_id, brand_id, status, unit, is_featured, position | **CERO** registros iniciales |
| `category_product` | category_id, product_id | Cardinalidad N:M si se permite |
| `product_media` | product_id, media_id, position, is_primary | Galería ordenada |
| `product_attributes` | product_id, name, value, unit, position | Características dinámicas |
| `preorders` | id, year, seq, public_code unique, customer_name/phone/email/company, observations, status, assigned_to, idempotency_key unique, created_at | **CERO** registros iniciales |
| `preorder_items` | preorder_id, product_id nullable, sku_snapshot, name_snapshot, unit_snapshot, quantity, metadata_snapshot | No alterar registro histórico por edición producto |
| `preorder_events` | preorder_id, actor_id nullable, from_status, to_status, note, created_at | Historial inmutable |
| `contact_submissions` | name, phone, email, company, message, status, consent_version, created_at | Proteger PII |
| `posts` | slug, title, excerpt, body_json/html sanitizado, status, featured_media_id, published_at | Noticias inicialmente cero |
| `post_revisions`, `post_categories`, `post_category_links` | cambios y clasificación | Versionado y filtros |
| `notifications_outbox` | event_type, aggregate_id, recipient, channel, payload_json, status, retries, next_retry_at, error_code | Separación DB vs entrega externa |
| `redirects` | old_path unique, target_path, status_code, enabled | Solo rutas aprobadas; evitar open redirects |
| `audit_logs` | actor_id, resource, id, action, before/after JSON redacted, ip_hash, created_at | Acceso restringido |
| `import_batches`, `import_errors` | import_id, actor, mapping, status, counts, safe_error | **Sin** importar catálogo heredado |
| `sequences` | sequence_name, year, next_number | Concurrencia y consecutivo sin duplicar |

Se pueden combinar algunas tablas por simplicidad, pero no suprimir control de revisiones, permisos, correlación e idempotencia. **Prueba automática tras `migrate:fresh --seed`: categorías 0, marcas 0, productos 0, contactos 0, preventas 0, posts 0**. Los únicos seeds permitidos son configuración base, roles y textos corporativos como borrador pendiente de aprobación. El superadmin inicial se crea mediante comando/instalador seguro con secreto entregado por canal privado o enlace de invitación de un solo uso.

### Índices mínimos

- `products (status, name)`, `products.sku UNIQUE`, `products.slug UNIQUE`, `categories.slug UNIQUE`, `brands.slug UNIQUE`.
- Si hay fulltext/collation disponibles, `FULLTEXT(name, description)` o servicio SQL equivalente; conservar búsqueda por SKU por `=`/prefijo.
- `preorders (status, created_at)`, `preorders (assigned_to, created_at)`, `preorders.public_code UNIQUE`, `preorders.idempotency_key UNIQUE`.
- `preorder_items (preorder_id)`, `contact_submissions (status, created_at)`, `notifications_outbox(status, next_retry_at)`.
- `posts (status, published_at)`, `audit_logs (resource, resource_id, created_at)`.

## 3. Operación crítica de preventa: idempotente y transaccional

**NO confiar en el carrito enviado por el navegador** para precios, nombres, SKU ni disponibilidad. Flujo:

```text
POST /api/preorders
  validar CSRF o auth de sesión / origen + rate limit + honeypot
  validar nombre, teléfono y consentimiento
  validar token idempotente de un solo intento lógico
  iniciar transacción
     ¿existe token? -> devolver resultado previo (sin duplicar)
     cargar por ID todos productos publicados
     rechazar ítems inexistentes, ocultos o cantidades inválidas
     tomar snapshot inmutable de SKU, nombre, unidad, cantidad
     bloquear fila secuencia (SELECT FOR UPDATE)
     reservar consecutivo único del año
     insertar preorders y preorder_items
     insertar evento 'recibida'
     insertar evento de notificación en outbox
  COMMIT
  devolver HTTP 201 o 200 idempotente con `JMAC-PV-AAAA-NNNNN`
  procesar outbox después del COMMIT mediante cron/job
```

Reintentos de red/recarga con el mismo token retornan el mismo número. Si SMTP cae, solicitud permanece `recibida` y notificación `failed`, no se confunde con una compra completada. Las notas de vendedor se controlan por roles.

## 4. Contrato de rutas (servidor y cliente)

| Método | Endpoint | Auth / propósito |
|---|---|---|
| GET | `/` | Public home SSR |
| GET | `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/` | Public, caché apropiada |
| GET | `/catalogo/?jmac_cat={slug}` | Public, compatibilidad histórica |
| GET | `/catalogo/{slug}/` | Public, ficha si publicada |
| GET | `/api/catalog/search?q=...&category=...&page=...` | Public, límites y paginación |
| POST | `/api/preorders` | Public, session/CSRF/antispam, idempotency key |
| POST | `/api/contacts` | Public, session/CSRF/antispam |
| GET | `/admin` | Auth + 2FA según rol |
| GET/POST/PUT | `/admin/pages...` | RBAC contenido |
| POST | `/admin/pages/{id}/publish` | RBAC publish + revision |
| POST | `/admin/theme/publish` | RBAC diseño + confirmación |
| GET/POST/PUT | `/admin/catalog/categories...` | RBAC catalog |
| GET/POST/PUT | `/admin/catalog/brands...` | RBAC catalog |
| GET/POST/PUT | `/admin/catalog/products...` | RBAC catalog |
| GET/PUT | `/admin/preorders...` | RBAC ventas |
| GET/PUT | `/admin/contacts...` | RBAC contactos |
| GET/POST/PUT | `/admin/posts...` | RBAC novedades |
| POST | `/admin/media/upload` | Auth/MIME/limites |
| POST | `/admin/system/cache-clear` | Superadmin + CSRF + audit |
| GET | `/sitemap.xml` y `/robots.txt` | Solo información pública aprobada |
| GET | `/admin/preview/{id}?token=...` | Sesión/token breve, noindex |

Los paths son un contrato lógico propuesto, no obligación de REST exacto; Laravel controllers pueden usar resource names bajo auth. Nunca dejar `/admin` accesible sin autenticación. En producción desactivar debug, no rutas `install` ni test con secretos en parámetros.

### Payloads de ejemplo

```json
{
  "idempotency_key": "UUID-generado-por-la-aplicacion",
  "customer": {"name": "Cliente ejemplo", "phone": "+50688888888", "company": "", "email": ""},
  "items": [{"product_id": 125, "quantity": 2}],
  "notes": "Necesito cotizacion",
  "privacy_accepted": true
}
```

**Es solo un ejemplo de contrato para cuando exista producto 125**; el catálogo real se instala sin productos y este payload debe rechazarse hasta que tal ID exista publicado.

## 5. Editor visual y bloques JSON

Guardar `blocks_json` solo con tipos autorizados. Ejemplo:

```json
{
  "schema_version": 1,
  "blocks": [
    {
      "id": "hero-home-jmac",
      "type": "hero",
      "data": {"headline": "UN PRODUCTO CON 20 AÑOS DE EXPERIENCIA", "image_media_id": null,
                "cta": {"label": "Ver catalogo", "href": "/catalogo/"}},
      "style": {"variant": "split", "spacing": "lg", "theme_token": "primary"},
      "visibility": {"desktop": true, "tablet": true, "mobile": true}
    }
  ]
}
```

Al publicar, validar esquema y referencias de media, sanitizar rich text por allowlist, rechazar JS/iframe arbitrario, colocar imágenes mediante IDs (no URLs externas sin allowlist), renderizar con vistas Blade confiables. Edición del bloque no debe cambiar inmediatamente la vista pública antes de publicar una nueva revisión.

## 6. Caché y performance

SSR + consultas selectivas + eager loading controlado; base catálogo paginada (`12-24`/página configurable), búsqueda SQL indexada; respuesta JSON solo datos útiles. Cache de secciones públicas versionado y purga al publicar (no borrar archivos). Minificar assets, HTTP cache para imágenes versionadas, compresión gzip/Brotli cuando cPanel permita, medir TTFB, LCP, CLS, INP sobre staging. Registrar `slow queries`, tiempo respuesta y errores sin guardar contenido sensible.

## 7. Correo/WhatsApp

Correo por SMTP con TLS, credenciales cifradas en `.env` o vault local, sin test SMTP en cliente. `outbox` para reintentos. WhatsApp click-to-chat a número E.164 configurable; si se instala WhatsApp Cloud API, sólo integración oficial con token seguro y webhooks validados, jamás scrapeo/sesiones no oficiales. En interfaz indicar resultado real: `solicitud registrada`, `correo pendiente`, `notificación enviada/fallida`.

## 8. Internacionalización y SEO

Mensajes español CR; zona horaria `America/Costa_Rica`, UTC en almacenamiento donde sea útil; fecha formateada local. Uso de slugs Unicode transliterados `ñ` -> `n` con mapeos explícitos, canonical permanente y redirección 301 cuando un slug cambia. `robots.txt` restringir zonas admin; staging `noindex`; OG imágenes aprobadas. Proteger lista pública contra spam/reflected XSS.

## 9. Configuración para portabilidad

Usar variables `APP_ENV`, `APP_KEY`, `APP_URL`, `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `MAIL_*`, `CACHE_STORE`, `SESSION_DRIVER`, `QUEUE_CONNECTION`, `FILESYSTEM_DISK`, `SESSION_SECURE_COOKIE`, sin valores secretos entregados por ChatGPT. Respetar límites de memoria/upload PHP y cron reales del host. Ofrecer `diagnostics:check`, `setup:verify`, `backup:verify`, health check no público con datos sensibles.


\newpage

# 05 · Seguridad, aislamiento de fuente comprometida y protección de datos

## 1. Regla máxima

**Crear un proyecto nuevo y limpio.** No ejecutar, copiar, instalar ni adaptar `themes.zip`, `uploads.zip` (como archivos sin filtrar), ni archivos PHP, HTML, JS, CSS, `.htaccess`, plugin, shortcode, extensión o ZIP encontrados en el hosting anterior. Las imágenes incluidas son únicamente candidatos re-guardados como raster. Los datos de CSV y de páginas son entrada no confiable, no código.

Hallazgo concreto: en `themes/ona-architecture/functions.php` hay contenido ofuscado con manejo de cookies, decodificación y carga dinámica. No es apto para servir de base ni como archivo para comparar funciones legítimas. No se requiere atribución del atacante: basta con **aislar y no reutilizar**. También se detectan registros de páginas claramente no corporativas y una inyección HTML en Catálogo. No importar nada de ello.

### Qué NO se hizo y qué no afirmar

No se realizó forense de servidor, revisión de logs, DNS completo, usuarios ni base integral. No puede afirmarse que todo el hosting quedó limpio ni que el dominio vuelve a servir contenido correcto. El paquete limpia la **selección de activos que se entrega**, no el alojamiento original.

## 2. Requisitos de aplicaciones

- Laravel o framework estable actualizado y versiones fijadas en `composer.lock` y lock JS; SCA/dependency audit en CI.
- Autenticación de sesión segura: hash `Argon2id`/bcrypt validado, rate limit de login, MFA/2FA TOTP para superadmins, regeneración de sesión y cookies `HttpOnly`, `Secure`, `SameSite=Lax/Strict` apropiado.
- CSRF en mutaciones web; API pública protegida por rate limit y validación/antispam; sin secretos en URLs.
- Middleware RBAC/policies **server-side** por entidad y acción, no solo menú oculto. Revalidar roles después de permisos editados, registrar cambios sensibles.
- Todo acceso a BD por ORM/queries parametrizados; nunca concatenar entrada del visitante en SQL.
- Escape salida por defecto; rich-text con allowlist sanitizada, no HTML arbitrario, inline scripts o `javascript:`. CSP realista y cabeceras `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`, HSTS tras comprobar HTTPS, frame protection según necesidades.
- Sanitización y verificación de imágenes: límite de bytes/píxeles, firma/MIME real, decoder confiable, reencode, rutas no controlables por usuario, nombres UUID/hash. Bloquear SVG activo y subida de PHP/PHTML/JS/ZIP/HTML.
- Ruta de subida segregada, sin permiso de ejecución y sin permitir `.htaccess` de usuario. `vendor`, `.env`, backups y logs **fuera** del document root.
- No enseñar stack traces/SQL/secretos en errores públicos. Logger con redacción de PII y retención razonable.
- Emails protegidos contra header injection; SPF/DKIM/DMARC de dominio configurados por proveedor. Rate limit tanto en envío como reintentos.
- Exportaciones y respaldos de registros personales solo roles autorizados, descarga temporal privada y registro de evento; impedir CSV injection al exportar.
- Password reset seguro con expiración y token de un solo uso; invalidar sesiones al desactivar usuario.

## 3. Seguridad de producción y cutover

1. Mantener sitio anterior aislado o en modo conservación de evidencia; no desplegar la nueva app dentro de un directorio con scripts viejos. Preferir cuenta de hosting/cPanel recién configurada o alojamiento limpiado profesionalmente.
2. Rotar claves comprometidas desde equipo seguro: cPanel, FTP/SFTP/SSH, MySQL, correos/SMTP, DNS/registrador y cualquier token. Revisar usuarios desconocidos y cron jobs; activar 2FA donde esté disponible.
3. Montar staging independiente en subdominio o entorno privado **sin indexación**. No apuntar el DNS de producción sin pruebas/permiso.
4. Copias de seguridad verificadas e inmutables del entorno nuevo; restauración ensayada. Mantener rollback del despliegue anterior (de la nueva app) sin reutilizar WordPress.
5. Revisar PHP mail transport, certificados, DNS y configuración TLS. El SSL debe tener dominio correcto y todas las rutas con HTTPS antes de aceptar preventas.
6. Deshabilitar listado de directorios, XMLRPC WP si quedara alguno en dominio viejo, evitar exposición de archivos `.sql`, `.zip` o `backup` en public_html.

## 4. Modelo básico de amenazas

| Riesgo | Mitigación verificable |
|---|---|
| Reutilizar malware del tema WP | Lista permitida imágenes raster re-guardadas; no PHP/JS/temas; escaneo repositorio nuevo |
| XSS en contenido CMS | Bloques tipados y sanitizer server-side, autoescape Blade, CSP |
| SQL injection | Query parametrizada, pruebas adversariales |
| CSRF edición/pedido | CSRF/session tokens y SameSite; tests 419 |
| Acceso no autorizado `/admin` | Auth, MFA, policies y tests 401/403 |
| Duplicar preventas por refresh | `idempotency_key` UNIQUE, transacción y locks |
| Archivos ejecutables en uploads | MIME/decoder, almacenamiento sin ejecución, rechazo extensiones |
| Privacidad de clientes | Minimización, RBAC, cifrado secretos, export restringido, retención |
| Falsificar entrega WhatsApp/mail | Outbox con estados por canal y observabilidad |
| Cache muestra contenido antiguo | Invalida por revisión publicada, cache versionado |
| Mala configuración cPanel | Document root solo `/public`, verify endpoint privado, check list |

## 5. Privacidad y consentimiento

Usar textos legales aprobados por asesoría local; no copiar `Privacy Policy` de muestra WordPress. Definir responsable, propósito, tiempo de retención, contacto para solicitudes de datos, cookies externas. Formularios capturan lo mínimo necesario para responder consultas y preventas. Permitir export/borrado/anonymización según reglas legales aplicables y preservar comprobación de consentimiento por versión cuando corresponda.

## 6. Revisión antes de despliegue

- `composer audit` / análisis dependencias, linters, tests y escaneo estático.
- Buscar en el repositorio artefactos sospechosos: `wp-`, `base64_decode` en lugares injustificados, `eval`, `shell_exec`, `exec`, archivos con `.php` dentro de uploads (escaneo no debe depender solo de patrones).
- Verificar cabeceras, cookies, credenciales, permisos OS, directorios, noexposure de `.env`, `storage`, `.git`, `vendor`.
- Revisar que el paquete final no contenga fuentes binarias exportadas del tema ni imágenes de apuestas o comercios ajenos.
- Validar que usuarios y datos comerciales empiezan sin migración anterior, excepto el superadmin nuevo explícitamente provisionado.


\newpage

# 06 · Instalación en cPanel, operación, respaldo y rollback

> Objetivo: instrucciones para instalar una aplicación PHP/MySQL **sin WordPress** en hosting con cPanel, sin requerir un servidor Node.js activo ni dominio externo de API. Estos pasos son la guía contractual para que Codex genere la documentación y el instalador reales. No se realizaron cambios en cPanel del usuario.

## 1. Compatibilidad que Codex debe comprobar ANTES de elegir stack

- PHP >= 8.3 preferible (comprobar versión y soporte concreto de framework), CLI PHP, extensiones `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `curl`, `xml`, `zip`, `intl` (si el host la posee), `gd` o `imagick` y `bcmath` si requiera formato monetario.
- Base de datos MySQL/MariaDB con versión, collation `utf8mb4`, límites de conexión, tamaño permitido y permisos para migrations.
- Directorio document root configurable a `/home/USER/jmac_app/public`, o posibilidad de servir únicamente el índice público sin exponer la app fuera de `public_html`.
- HTTPS AutoSSL/Let's Encrypt activo y válido para staging y dominio final.
- Cron jobs disponibles y frecuencia real; permitir `php artisan schedule:run` y una tarea finita de queue (`queue:work --stop-when-empty` / job con límites); no asumir daemon Supervisor.
- SMTP saliente con autenticación/TLS; configurar SPF/DKIM/DMARC en dominio si se usa email corporativo.
- SSH/Terminal/Composer si existe; si no, construir `vendor` y frontend por CI/local y subir paquete probado por SFTP/Administrador de archivos.
- Espacio libre para storage/media/backups, tiempo CPU y memoria PHP, máximo de subida, posibilidad de reescritura Apache y soporte de logs.

Crear `CPANEL_COMPATIBILITY.md` en el repo con resultados concretos, supuesto, bloqueo y solución.

## 2. Preparación

1. **Backup** del estado anterior sin ejecutarlo ni usarlo como origen de archivos públicos. Guardar copia fuera de document root y fuera del nuevo paquete de app.
2. Si el cPanel anterior se considera comprometido, recomendar hosting/cuenta nueva o limpieza certificada antes de desplegar. Rotar credenciales y revisar acceso de terceros.
3. Crear subdominio de staging (ej. `staging.jmaccr.com`) en carpeta/dominio separado, con acceso restringido y `noindex`, preferiblemente Basic Auth a nivel servidor.
4. Crear DB nueva, usuario DB nuevo y conceder privilegios mínimos aplicables; registrar valores en un gestor seguro. No compartir contraseñas en chat/documentos/repositorio.
5. Configurar `APP_URL`, zona `America/Costa_Rica`, SMTP y mecanismos de persistencia con `.env` server side.

## 3. Layout seguro

**Preferido:**

```text
/home/USUARIO/
  jmac_app/             ← todo Laravel, vendor, .env, storage, tests opcionales
    public/             ← DOCUMENT ROOT del dominio nuevo
      index.php
      build/
  backups_privados/     ← fuera del sitio web
```

Si cPanel no permite cambiar docroot del dominio principal, documentar la opción verificada de mantener proyecto completo fuera de `public_html` y solo un `index.php`, CSS/JS/media públicos dentro de `public_html`, con rutas bootstrap adaptadas a rutas reales de hosting y archivos privados inaccesibles. No copiar el framework completo a `public_html` ni usar `.htaccess` como única defensa de `.env` situado públicamente.

Evitar dependencia de symlinks si el host los deshabilita; servir media pública mediante rutas seguras o un directorio controlado. Permisos archivo normalmente `0644` y directorio `0755`, storage/cache con escritura restringida al usuario PHP según host. Evitar `0777`.

## 4. Build y despliegue reproducible

1. En estación de desarrollo/CI: `composer install --no-dev --prefer-dist --optimize-autoloader`, `npm ci && npm run build`, ejecutar tests antes del empaquetado, y generar manifest de checksums.
2. Preparar artefacto release con dependencias y `public/build` construidos; **no** incluir `.env` ni secretos; tampoco material WordPress anterior.
3. Transferir release a carpeta privada fuera del document root. Crear `.env` de producción en servidor desde `.env.example` y generar `APP_KEY` por comando seguro; validar conexión DB.
4. Ejecutar `php artisan migrate --force` una vez tras backup y validación del schema. Seed de roles/configuración únicamente: **comprobar categorías, marcas, productos, noticias y preventas en cero**.
5. Crear superadmin mediante comando de invitación de un solo uso/MFA inicial. No contraseñas default ni generadas en texto del README.
6. Preparar caches de Laravel apropiadas (`config:cache`, `route:cache`, `view:cache`), comprobar storage/web media y escritura de logs. Optimización segura sin cachear valores secretos en repositorio.
7. Configurar cron/queue con ruta real de PHP y carpeta app. Si el host soporta cron cada minuto:

```cron
* * * * * cd /home/USUARIO/jmac_app && /usr/local/bin/php artisan schedule:run >> /dev/null 2>&1
```

**Solo es un ejemplo**: Codex debe comprobar rutas y frecuencia reales de cPanel; si el proveedor limita a 5 minutos, ajustar expectativas y configurar trabajos no dependientes de resolución inmediata.

8. Configurar HTTPS real, cookies secure, APP_DEBUG=false, forzar HTTPS, cabeceras de seguridad y caché de assets versionados.
9. Comprobar pruebas de humo, flujo de contacto/preventa, datos vacíos, reportes, MFA, miniaturas, email de prueba, compatibilidad móvil.
10. Tras revisión y aprobación del propietario, realizar corte: backup y snapshot de DB, migrar cambios desde staging y apuntar dominio, conservar mecanismo de rollback y verificar SEO/SSL/correos.

## 5. Migraciones y semillas

El sitio NO debe ejecutar un importador de WP. El archivo `SEMILLA_CORPORATIVA_BORRADOR.json` es un origen opcional para **borradores**, no datos de catálogo ni publicaciones automáticas. Prohibido cargar histórico de categorías y productos. Al terminar instalación, consultar cuentas:

```sql
SELECT COUNT(*) AS total FROM products;
SELECT COUNT(*) AS total FROM categories;
SELECT COUNT(*) AS total FROM brands;
SELECT COUNT(*) AS total FROM preorders;
SELECT COUNT(*) AS total FROM posts;
```

Todas deben devolver `0`. Verificar que `users` contiene solo la cuenta nueva creada explícitamente y roles técnicos necesarios.

## 6. Backups, restauración y rollback

- Frecuencia propuesta: SQL diario y activos/media diario o incremental según cambios, retención configurable (ej. 7 diarias, 4 semanales, 3 mensuales); ajustar a capacidad del hosting. No dejar ZIP públicos en `public_html`.
- Cifrar backups y almacenarlos fuera del servidor o en almacenamiento externo seguro; documentar restauración sobre staging, verificar conteos, usuarios/permisos/archivos.
- Antes de actualizar app: punto de restauración de código + DB, ventana de mantenimiento breve, compatibilidad schema y release anterior listo. En migraciones no reversibles, plan escrito de restore.
- Monitorear emails no enviados, fallos cron, errores 500, disco lleno y certificados; alertas al administrador. Registrar backups exitosos y fallidos.
- Políticas de recuperación aproximadas RPO/RTO para propietario, **no** prometer horas sin medir servicio de hosting.

## 7. Checklist go-live de cPanel

- [ ] Nueva app instalada en carpeta segura, aislada de WordPress anterior.
- [ ] Revisión host y contraseñas/2FA completada.
- [ ] SSL válido/HTTPS redirige sin loops; mixed content 0.
- [ ] `.env`, `.git`, storage privado, ZIP/SQL y vendor inaccesibles vía navegador.
- [ ] Login admin/MFA, reset y control de permisos probados.
- [ ] Portada, nosotros, contacto, novedades, catálogo funcionan móvil/escritorio.
- [ ] Cero categorías, marcas, productos, noticias y preventas hasta carga desde admin.
- [ ] Alta de primer producto en staging, su publicación, filtrado, buscador y preventa probados, después eliminar datos de prueba.
- [ ] Emails/contactos persistidos con registro real y errores visibles.
- [ ] SEO/sitemap/canonical correctos, staging no indexado, production indexado solo páginas aprobadas.
- [ ] Backups y proceso de restore probados.
- [ ] Logs sin datos personales/secretos, debug OFF, sin PHP ejecutable en media.
- [ ] Conformidad visual/editorial del propietario.

## 8. Manuales obligatorios a Codex

`INSTALL_CPANEL.md` (capturas o pasos exactos de cPanel), `UPDATE_CPANEL.md`, `BACKUP_RESTORE.md`, `ADMIN_MANUAL.md` (para dueño que no programa), `TECHNICAL_ARCHITECTURE.md`, `SECURITY_CHECKLIST.md`, `.env.example`, `RELEASE_NOTES.md` y `TROUBLESHOOTING.md`. No marcar “instalado” si no se realizó deployment en hosting de prueba o no se recibió acceso/confirmación.


\newpage

# 07 · QA, pruebas automatizadas y criterios de aceptación

## 1. Filosofía de prueba

Cada botón anunciado debe ejecutar acción real. Pruebas unitarias + Feature HTTP/BD + Browser/E2E según recursos del repositorio. Usar fixtures de ejemplo **solo** en test/staging y limpiar antes de instalación productiva. No enviar notificaciones reales a clientes durante pruebas. Capturar evidencia de resultados y fallos.

## 2. Matriz de aceptación

| ID | Módulo | Escenario | Resultado requerido |
|---|---|---|---|
| T001 | Instalación | BD `migrate:fresh --seed` | categorías=0, marcas=0, productos=0, noticias=0, preventas=0 |
| T002 | Sitio | GET `/`, `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/` | 200, diseño corporativo, sin WordPress/SEO basura |
| T003 | SEO | Sitemap/robots/canonical | 0 rutas basura, índice solo páginas publicadas |
| T004 | Diseño | Cambiar color/hero en admin y publicar | Front actualiza sin programar; borrador no altera público |
| T005 | Diseño | Restaurar revisión previa | Visual y contenido regresan, auditoría mantiene evento |
| T006 | Menú | Añadir/reordenar/ocultar enlace | Reflejado desktop/móvil, URL válida |
| T007 | Admin | Visita `/admin` sin login | 302 login o 401, nunca información sensible |
| T008 | Admin | Login incorrecto repetido | Rate limit, sin enumeración de usuario |
| T009 | Permisos | Rol ventas intenta cambiar tema/producto | HTTP 403, no alteración BD |
| T010 | Permisos | Rol editor intenta ver datos de preventas | HTTP 403 |
| T011 | MFA | Superadmin sin segundo factor configurado | Flujo de enrolamiento seguro obligatorio |
| T012 | Categorías | Crear categoría con imagen | Visible en catálogo en orden definido |
| T013 | Categorías | Duplicar slug o ciclo | Error validación, BD consistente |
| T014 | Productos | Crear borrador | No aparece públicamente |
| T015 | Productos | Publicar nuevo producto con SKU | Búsqueda nombre/SKU, ficha y galería funcional |
| T016 | Productos | SKU duplicado | Error validación sin sobrescribir |
| T017 | Productos | Archivar producto | Desaparece de nuevos carritos, preventas antiguas mantienen snapshot |
| T018 | Catálogo | `/catalogo/` vacío | 200, estado vacío elegante, cero datos ficticios |
| T019 | Búsqueda | Palabras con acentos, SKU, sin resultados | Respuesta correcta y paginada |
| T020 | Filtros | Enlace `?jmac_cat=cadenas` con categoría inexistente | Vista vacía válida, sin error 500 |
| T021 | Carrito | Agregar/quitar/modificar cantidad | Contador y resumen sincronizados |
| T022 | Preventa | Enviar datos incompletos | 422 o errores de campo, nada guardado |
| T023 | Preventa | Producto despublicado en carrito | Rechazo claro, no se inserta ítem inválido |
| T024 | Preventa | Enviar válida | Transacción confirmada, número único y snapshot |
| T025 | Preventa | Doble click/reintento misma idempotency_key | UNA sola solicitud, misma referencia |
| T026 | Preventa | Dos solicitudes simultáneas diferentes | Consecutivos únicos y consistentes |
| T027 | Preventa | SMTP caído | Solicitud guardada, outbox failed/pending visible, no falsa entrega |
| T028 | Preventa | Cambio de estado por ventas | Timeline y usuario registrado, notificación apropiada |
| T029 | Contacto | Formulario válido con correo caído | Contacto persiste en BD, error notificación rastreable |
| T030 | Contacto | spam/honeypot/rate limit | Bloqueo/rate limit sin afectar tráfico legítimo |
| T031 | Blog | Publicar/retirar novedad | Index y detalle correctos, SEO actualizado |
| T032 | Media | Subir JPG/PNG/WEBP válidos | Miniaturas + ALT + reencode |
| T033 | Media | Intentar PHP disfrazado `.jpg`/ZIP/SVG activo | Rechazo, nunca ejecución |
| T034 | XSS | Inyectar JS en editor/ficha/contacto | Escapado/sanitizado, sin ejecución |
| T035 | CSRF | POST modificación sin token | Rechazo, BD sin cambios |
| T036 | SQLi | `q` con caracteres especiales SQL | Resultado seguro, sin errores SQL ni fuga |
| T037 | Rendimiento | 1k productos simulados en test | Paginación sin cargar todo, tiempos medidos |
| T038 | Responsive | 360/390/768/1024/1440 px | Sin scroll horizontal anómalo, CTA accesible |
| T039 | Accesibilidad | Teclado/lector texto/labels/foco | Cumple controles básicos WCAG AA |
| T040 | cPanel | Instalar artefacto limpio | Web y admin funcionan sin servidor Node |
| T041 | cPanel | Visitar `/.env`, `/vendor/`, `/storage/logs/...` | Denegación consistente, sin filtración |
| T042 | cPanel | Cron/colas/SMTP | Procesan, registran éxito/error, no requieren daemon |
| T043 | Operación | Restaurar backup en staging | App recupera páginas, productos nuevos y usuarios autorizados |
| T044 | Auditoría | Cambiar roles/diseño/preventa | Registro de usuario/fecha/cambio, sin secretos |
| T045 | Migración | Buscar referencias antiguas en BD nueva | No existe ninguna fila heredada, ni productos históricos |
| T046 | Publicación | Referencias de assets | Solo `assets_limpios/` aprovados y nuevos uploads sanos |
| T047 | Seguridad | Inspección dependencia/hardcoded keys | No hay secretos/WordPress/malware en repo o release |
| T048 | Aprobación | Validación visual con dueño | Capturas y checklist aprobados, diferencias conocidas listadas |

## 3. Pruebas transversales

### UI

Pantallas desktop 1440 y móvil 390; además 360, 768, 1024. Verificar estados: vacío, cargando, éxito, error, paginación sin registros, formulario inválido, permiso insuficiente, teléfono/WhatsApp sin configurar. El diseñador no debe producir secciones rotas en pantalla pequeña.

### Rendimiento, métricas

Medir Lighthouse de staging en varias visitas; metas *orientativas* iniciales y sujetas a host/red: LCP <= 2.5 s, CLS <= 0.1, INP <= 200 ms en dispositivos/condiciones evaluadas, no prometer cumplimiento sin medición. TTFB y tamaño total de página documentados. Revisar consultas N+1 y utilización de memoria PHP.

### Seguridad

Pruebas 401/403, cookies Secure/HttpOnly/SameSite, Csrf, XSS, SQL injection, files upload, rutas privadas, open redirect, sniff, reset token expiry, MFA y exclusión de secretos de logs.

### Negocio

El sitio vacío no se ve roto; tras crear una categoría/producto desde el administrador, se publica correctamente. El operador recibe una preventa real con cantidad/código, cambia estados, usa el consecutivo y consulta notas. WhatsApp click-to-chat **no** se etiqueta como mensaje entregado.

## 4. Definición de terminado (DoD)

1. Código desplegable, dependencias fijadas y procedimientos reproducibles.
2. Tests relevantes verdes e informe de ejecución adjunto; bloqueos documentados si no hay hosting.
3. Panel real completo y permisos comprobados.
4. Front público y contenido corporativo aprobados por el propietario o marcados explícitamente como pendientes.
5. Catálogo real inicialmente cero, carga desde admin de cero y sin productos heredados.
6. Preventas/correo/contacto funcionan con fallas gestionadas.
7. Seguridad no depende de tema original y cPanel mantiene secretos fuera del público.
8. URLs históricas funcionan o redirigen según lista aprobada; sin páginas de terceros.
9. Respaldo/restauración y recuperación probados antes de corte DNS.
10. Manual de usuario para no programadores y guía cPanel paso a paso publicados con la versión.

Codex no puede marcar etapa terminada si solo hay componentes visuales sin backend, datos persistentes o seguridad real.


\newpage

# 08 · Plan de ejecución recomendado para Codex

## Hito 0 — Diagnóstico y arquitectura (sin tocar producción)

- Leer este paquete completo y la evidencia. Revisar repositorio destino e historia, si existe.
- Crear matriz `verificado/parcial/desconocido`, arquitectura, extensiones PHP cPanel y ADRs.
- Aprobar stack y uso de migraciones; diagramar permisos y entidades.
- Listar pendientes editoriales, sin bloquear tareas técnicas.
- Entregar checklist para dueño y demostrar repositorio limpio.

**Salida:** `ARCHITECTURE.md`, `CPANEL_COMPATIBILITY.md`, `SECURITY_BASELINE.md`, task board, diseño DB.

## Hito 1 — Infraestructura limpia

- Proyecto PHP estable, conexión DB, migrations, seeds solo roles/config y borradores corporativos, login/MFA/RBAC.
- Infraestructura CSS/JS SSR, documentación `.env.example`, tests, CI, staging.
- Configurar audit, policy, caching básico y subidas seguras.
- Demostrar que catálogo, marcas, categorías, posts y preventas inician cero.

**Puerta de avance:** tests de seguridad y datos vacíos verdes, login funcional, no WordPress.

## Hito 2 — Sitio público e identidad

- Templates Blade y bloques corporativos configurables.
- Inicio, Nosotros, Contacto, Novedades, Catálogo, menús y footer.
- Copiar selectivamente imágenes **ya re-guardadas**, convertir a tamaños web y hacer manual de media.
- Responsive, SEO base y estados vacíos.

**Puerta:** rutas reales 200, front usable móvil, no textos inventados, imágenes corporativas aprobables.

## Hito 3 — CMS/editor visual y marca

- Admin: páginas, biblioteca de bloques, preview por dispositivo, revisiones, publish/rollback, menús, medios, branding, portada, footer.
- Permitir cambiar prácticamente toda la apariencia sin desarrollador y restringir diseño que rompa UI.
- Tests de publicación/no publicación, control de roles y persistencia.

**Puerta:** propietario puede cambiar logo, hero, copy, colores, menús, secciones sin programar y con undo.

## Hito 4 — Catálogo nuevo desde cero

- CRUD categorías/subcategorías, marcas, productos, atributos, fotos, PDF, slugs, búsqueda/filtros.
- UI pública con carrito, productos destacados opcionales y estado vacío inicial.
- Importador futuro deshabilitado por defecto y **nunca ejecutar importación vieja**.

**Puerta:** crear primer producto desde admin en staging, encontrar por nombre/SKU, agregar al carrito; BD producción sin heredados.

## Hito 5 — Preventas, contactos y notificaciones

- DB transaccional, consecutivo seguro, snapshots, idempotencia, estados, workflow ventas.
- Formularios y bandejas, SMTP, outbox y WhatsApp configurable.
- Exportaciones y reportes básicos con protección de PII.

**Puerta:** 1 solicitud válida persistida, reintento sin duplicar, correo fallido rastreable y atención por roles.

## Hito 6 — Novedades, SEO avanzado, auditoría

- Editor blog nuevo, estados/revisiones, portada, sitemap, redirecciones 301, OG/schema.
- Registro cambios admin, análisis multimedia no usada, respaldo y salud del servidor.

**Puerta:** publicar noticia y rollback; no indexar admin/staging.

## Hito 7 — QA, cPanel y salida

- Tests integrales 48 casos, validación performance/a11y/responsive, revisión de seguridad.
- Preparar paquete release para cPanel; instalación staging y prueba de backups/rollback.
- Manuales y video/guía visual opcional, firma de aprobación.
- Cambio a producción solo tras permiso expreso del propietario.

**Puerta:** `07_PRUEBAS_Y_ACEPTACION.md` completo; reporte final de hallazgos y pendientes firmado.

## Política de entregas entre hitos

Al terminar cada hito Codex debe informar: archivos modificados, endpoints/páginas nuevos, screenshot o evidencia real del panel/usuario, tests ejecutados y resultados, riesgos, cambios de esquema, cómo desplegar y qué necesita del propietario. Solicitar clarificación solo cuando bloquea una decisión esencial; otras cosas se dejan administrables y desactivadas.

## Pendientes para una fidelidad visual 100% exacta

Los respaldos no incluyen capturas de todas las páginas ni export `wp_template` / `wp_template_part` / `wp_navigation` / `wp_block` ni opciones completas del FSE. Además, la web pública actual responde irregularmente; por tanto no se debe garantizar que una maqueta nueva sea idéntica píxel a píxel. Ver `09_DATOS_PENDIENTES_Y_SQL.md` para extracción complementaria de solo lectura. Sí hay fotografías corporativas, logo, estructura y textos de portada suficientes para iniciar desarrollo.


\newpage

# 09 · Datos pendientes y consulta opcional de plantillas WordPress FSE

## 1. Importante: por qué las páginas del CSV no tienen texto

Se recibieron `wpfd_posts.csv` y `wpfd_options.csv`. La primera exportación recupera `post_type='page'`, pero en ella `Nosotros`, `Contacto` y `Novedades` tienen `post_content` vacío. Esto no autoriza inventar sus textos; el diseño anterior puede haberse generado en plantillas FSE guardadas en otra clase de registros. No era necesario Elementor: el tema Ona es de bloques WordPress Full Site Editing, que soporta plantillas y partes almacenadas como `wp_template`, `wp_template_part`, `wp_navigation` y `wp_block`.

**No necesitas regresar al wp-admin.** Si quieres mejorar la paridad de la web legítima, opcionalmente puedes consultar esas tablas desde phpMyAdmin con SQL de solo lectura y compartir el export filtrado. No es requisito para arrancar el desarrollo. **No es seguro ejecutar/importar** el HTML heredado directamente en la nueva app; primero revisarlo.

## 2. Consulta de plantillas y navegación

Usar `wpfd_posts` **solo si ese es el nombre real de tu tabla** (confirmarlo en phpMyAdmin). Ejecutar en la pestaña SQL y exportar resultados como CSV UTF-8. **Solo hace SELECT**:

```sql
SELECT
    ID, post_type, post_status, post_title, post_name,
    post_content, post_date, post_modified
FROM wpfd_posts
WHERE post_type IN ('wp_template', 'wp_template_part', 'wp_navigation', 'wp_block')
AND post_status IN ('publish', 'draft', 'private')
ORDER BY post_type, post_name, ID;
```

Antes de entregar el CSV: excluir scripts, inyecciones, enlaces ajenos y valores que expongan credenciales o datos privados. Si notas páginas claramente ajenas, descartarlas; no reutilizar su contenido.

## 3. Configuración adicional opcional del tema

Solo leer nombres de opciones primero, sin exportar todos sus valores:

```sql
SELECT option_name
FROM wpfd_options
WHERE option_name LIKE 'theme_mods_%'
   OR option_name LIKE 'wp_global_styles%'
   OR option_name LIKE 'ona_%'
ORDER BY option_name;
```

Un segundo export de **opciones específicas revisadas** puede ayudar a reconstruir colores, logos, menús o estilos. Las opciones pueden contener HTML, terceros, secretos o payloads maliciosos, así que no se deben enviar indiscriminadamente. El valor `stylesheet=ona-architecture` fue obtenido, pero no garantiza que esta plantilla representara el sitio de antes del ataque.

## 4. Material corporativo a confirmar con JMAC

| Campo | Valor actual | Acción |
|---|---|---|
| Nombre | JMAC | Confirmado |
| Lema | LIDER EN EL MERCADO INDUSTRIAL | Confirmado |
| Logo | `logo-jmac.png` del respaldo | Aprobación visual y derechos |
| Texto portada | Referencia indexada y banner original con ligera variante | Escoger redacción final |
| Teléfono comercial | **Sin verificar** | Configurar desde admin |
| WhatsApp | **Sin verificar** | Configurar desde admin |
| Email / remitente SMTP | **Sin verificar** | Configurar desde admin |
| Dirección y mapa | **Sin verificar** | Configurar desde admin |
| Redes sociales | **Sin verificar** | Configurar desde admin |
| Historia, misión, visión | **No recuperadas** | Redactar con dueño, no inventar |
| Páginas legales | Ejemplo WP no utilizable | Texto legal nuevo aprobado |
| Fotografía de personas | Re-guardada como candidato | Confirmar autorización de uso |
| Colores exactos / tipografía / layout | Parcial | Revisar mockup y aprobar |
| Portal antiguo de Reportes JMAC | Solo shortcode sin código | Definir si se recrea en admin |
| Catálogo anterior | **Decisión: no reutilizar** | Crear todo desde cero |

## 5. Qué no hace falta entregar

No enviar WordPress completo, `wp-admin`, `wp-includes`, plugins antiguos, respaldo completo sin depurar, usuarios/contraseñas, SQL con datos personales, archivos ejecutables, scripts sospechosos o catálogos históricos. El proyecto nuevo se construye sin ejecutar archivos del origen.

## 6. Criterio para cerrar la parte editorial

Al presentar maqueta de staging, JMAC debe aprobar: logo y variantes, portada/banner, menú, estructura de Nosotros, contacto, pie, colorimetría y textos. Codex guardará esas aprobaciones y documentará cualquier diferencia respecto al diseño histórico. Si no existen pruebas confiables para un detalle, marcar `reconstrucción propuesta`, nunca `réplica exacta comprobada`.


---

# Apéndice · Referencias gráficas recuperadas

El siguiente mosaico muestra los **10 recursos raster corporativos candidatos** incluidos en la entrega, no una captura de pantalla fiel de la web. Las imágenes han sido re-guardadas y requieren selección/aprobación.

![Mosaico de imágenes para JMAC](REFERENCIAS_DISENO.jpg)

**Archivos técnicos adjuntos:** `PROMPT_MAESTRO_CODEX.md`, `SEMILLA_CORPORATIVA_BORRADOR.json`, `CATALOGO_INICIAL_VACIO.csv`, `AUDITORIA_PAGINAS.csv`, `MANIFIESTO_IMAGENES.csv`, `EXTRACCION_OPCIONAL_FSE_SOLO_LECTURA.sql`, `assets_limpios/`.
