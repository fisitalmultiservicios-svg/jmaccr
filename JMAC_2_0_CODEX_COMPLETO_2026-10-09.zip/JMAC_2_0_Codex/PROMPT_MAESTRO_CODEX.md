# PROMPT MAESTRO PARA CODEX · RECONSTRUCCIÓN JMACCR.COM SIN WORDPRESS

Eres el ingeniero principal responsable de implementar desde cero el proyecto **JMAC 2.0**, web corporativa + catálogo de solicitudes de preventa + CMS visual completo. Tu fuente contractual son TODOS los archivos `README_EMPEZAR_AQUI.md`, `01_...` a `09_...`, CSV/JSON y carpeta `assets_limpios/` de este paquete. **Léelos por completo antes de escribir código**. No ignores criterios porque parecen extensos.

## Prioridades y restricciones no negociables

1. **No WordPress, Elementor, WooCommerce ni plugins/código del sitio comprometido**. Usa app PHP limpia con base MySQL/MariaDB, render server-side y recursos estáticos compilados; compatible con **hosting cPanel compartido**, sin Node persistente en producción. Evalúa PHP/Laravel estable en función del hosting, documenta ADR.
2. **No importar el catálogo anterior bajo ningún concepto.** Instalación con 0 productos, 0 categorías, 0 marcas, 0 preventas, 0 artículos nuevos. El archivo CSV histórico del proyecto antiguo NO debe utilizarse. `CATALOGO_INICIAL_VACIO.csv` está vacío deliberadamente. Solo se creará información nueva desde el Admin.
3. Conservar exclusivamente la **identidad y contenidos corporativos legítimos de JMAC** recuperados. El logo y fotografías re-guardadas están en `assets_limpios/`; mantener las imágenes como candidatos hasta aprobación del dueño. No importar imágenes de apuestas, sitios extraños, otros productos ajenos ni código WP. El tema hijo `ona-architecture/functions.php` del respaldo presenta código malicioso/ofuscado **y no debe usarse**. No incluir respaldos fuente antiguos en el release.
4. Se han identificado rutas corporativas `/`, `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/`. Mantener navegación `Inicio | Nosotros | Contáctanos | Novedades | Catálogo`, slug y comportamiento del catálogo/preventa; las categorías del sitio histórico son **solo referencia UX y NO registros iniciales**.
5. El propietario necesita poder modificar **prácticamente TODO desde un backend**, tanto estética como contenido: textos, secciones, bloques, banners, slider, logo, colores, fuentes, tamaños, menús, footer, multimedia, catálogo, categorías, marcas, productos, noticias, SEO, usuarios, preventas y consultas. Debe incluir constructor visual por bloques editables, reordenables, responsivos, con vistas previas, revisiones, publicar/rollback y controles reales; NO basta con un CRUD básico.
6. `Nosotros`, `Contacto`, `Novedades` aparecen vacías en el CSV `wpfd_posts.csv`, posiblemente porque FSE guarda plantillas en `wp_template`/`wp_template_part`; no inventar historia/misión/contactos. Referencia `SEMILLA_CORPORATIVA_BORRADOR.json` para textos conocidos en estado DRAFT, nunca publicación automática. Portada conocida: experiencia de 20 años, confianza, orgullosamente ticos, unión experiencia/tecnología/calidad, lema JMAC.
7. Catálogo tipo **solicitud de preventa**, no carrito de pagos. Interfaz con categorías, filtros, búsqueda nombre/código, imágenes, SKU, fichas y **Cargar al carrito**; preventa recopila Nombre, Teléfono y Empresa opcional, con otros campos opcionales. Validación del servidor, confirmación de consecutivo, estados, histórico y notificaciones reales. Evitar doble envío con token idempotente y transacciones/consecutivo seguro; snapshot de líneas para histórico. Apertura WhatsApp no significa envío confirmado. Sin pasarela de pago/precios públicos por defecto.
8. Seguridad desde inicio: Auth + roles/RBAC server-side + MFA admins, CSRF, XSS, SQL parametrizado, antispam/rate limits, upload permitido solo media validada/reprocesada, backups, auditoría, correos en outbox, `.env` y storage fuera document root, ninguna clave real en repositorio. No hacer cambios de DNS/cPanel/produc. sin consentimiento.
9. Manual cPanel paso a paso para alguien sin conocimientos de programación, entorno staging, pruebas, evidencia de funcionamiento y paquete instalable. Build JS/CSS antes de subir; sin servidores Node/queues de procesos persistentes requeridos.
10. **La réplica visual exacta no está verificada**, porque la web pública fue alterada y los CSV de páginas no traen todos los bloques. Diseña una reconstrucción empresarial fiel basada en las imágenes/textos corporativos y ofrece validación por captura/propietario. Nunca digas “100% exacto” sin contraste aprobado.

## Qué construir exactamente

**Frontend:** páginas Inicio/Nosotros/Contacto/Novedades/Catálogo y detalles; responsive desktop/tablet/móvil, layout industrial profesional J-MAC azul/blanco ajustable, metas SEO, accesibilidad, menús/pie editables, componentes condicionales cuando catálogo/blog están vacíos. Integrar fotografías corporativas aprobadas de assets_limpios, sin fotomontajes o imágenes ajenas no autorizadas.

**Admin:** Dashboard; Sitio > Páginas/constructor, Diseño global, Menús, Medios; Catálogo > Categorías, Marcas, Productos, Especificaciones; Solicitudes > Preventas, Contactos, Notificaciones; Comunicación > Novedades; Sistema > Usuarios/roles, SEO, Configuración, SMTP, WhatsApp, Auditoría, Backups, Vaciar caché y Diagnóstico. Formularios en español, filtros/paginación, validaciones, guardado fiable y estados.

**Datos:** implementar migrations y relaciones descritas en `04_ARQUITECTURA_DATOS_Y_API.md`, seed técnico mínimo y semilla corporativa como **borradores no publicados**. Deben persistir revisiones del CMS, productos/categorías, snapshots de preventas, eventos, mensajes, medios, usuarios y auditoría; datos personales protegidos. Cero datos del catálogo WP.

**Implantación:** cPanel + PHP 8.3 si disponible, BD MySQL, rutas rewrite, assets build locales, cron limitados, SMTP; procedimiento reproducible, tests y rollback. No asumir SSH/composer en hosting sin comprobar. No copiar todo el framework dentro de `public_html`.

## Orden de trabajo obligatorio

**Hito 0:** inspecciona repositorio actual, versión PHP/MySQL requerida y cPanel real (si no hay acceso, genera cuestionario técnico y continúa con supuestos). Presenta arquitectura, lista de tareas y matriz de riesgo. No pedir catálogos heredados.

**Hito 1:** app limpia, CI, migraciones, RBAC y MFA, seed 0 productos/categorías/marcas, políticas y seguridad base. Ejecutar tests y reportar.

**Hito 2:** home/nosotros/contacto/novedades/catalogo, diseño corporativo con media aprobable y responsive, SEO/estados vacíos.

**Hito 3:** CMS visual completo con bloques, editor tema, cabecera/pie, medios, revisiones, vista previa/rollback, edición real sin código.

**Hito 4:** catálogo desde cero, CRUD categorías, marcas y productos, búsqueda, fichas, filtros, carrito; demostrar creando datos nuevos de prueba en staging y eliminándolos al finalizar.

**Hito 5:** preventas idempotentes y transaccionales, bandeja de ventas, contactos, correo/outbox y WhatsApp configurable.

**Hito 6:** blog, SEO/redirects, auditoría, backups, diagnóstico, pruebas de carga y control de permisos.

**Hito 7:** deploy/release para cPanel, staging, QA (48 casos de `07_PRUEBAS_Y_ACEPTACION.md`), manuales, entrega final y aprobación del dueño. No pasar a producción sin autorización.

Al cerrar CADA hito: indicar código modificado, migrations, rutas, capturas o evidencia real, comandos de test ejecutados con resultados, pendientes y pasos para probar. No “completado” si hay botones decorativos o mocks. Puedes dividir cada hito en PR/commits atómicos. Evitar iniciar todos a la vez sin pruebas.

## Primeras tareas que debes ejecutar ahora

1. Leer `README_EMPEZAR_AQUI.md` y todos los archivos Markdown, JSON y CSV del paquete.
2. Revisar repo actual (si existe). No sobrescribir sin plan/backups.
3. Escribir un plan detallado de implementación y escoger framework compatible con cPanel documentando decisión y requisitos.
4. Definir estructura de rutas, permisos, tablas, editor de bloques y contratos de preventa.
5. Comenzar Hito 0 / Hito 1; implementar código real y tests.
6. Confirmar por tests que las categorías, marcas y productos iniciales son **CERO**.

## Criterios definitivos de aceptación

La entrega es una app real no WordPress, lista para alojar en cPanel, con interfaz corporativa aprobable, **panel visual integral**, catálogo completamente nuevo administrable, preventas persistidas con consecutivo/flujo de ventas, contactos/noticias, permisos/seguridad, SEO, backups y manuales. Si faltan contactos o textos originales, deben quedar pendientes editables y explícitos, nunca inventados. El paquete anterior contaminado no se vuelve a ejecutar.
