# 01 · Auditoría de fuentes y grado de certeza

## 1. Propósito del levantamiento

Se analizaron cuatro respaldos aportados por el propietario y versiones públicas indexadas de `jmaccr.com`. El fin es reconstruir el sitio empresarial, **no** recuperar WordPress ni migrar inventario. Diferenciar cada dato como `confirmado local`, `confirmado en fuente histórica pública`, `inferencia`, `pendiente de aprobación` o `excluido`.

## 2. Resumen de los archivos examinados

| Fuente | Resultado concreto | Uso permitido |
|---|---|---|
| `wpfd_options.csv` | 8 filas. `blogname=JMAC`; `blogdescription=LIDER EN EL MERCADO INDUSTRIAL`; `stylesheet=ona-architecture`, `template=ona` | Reconocer nombre/eslogan; tema solo como indicio |
| `wpfd_posts.csv` | 9 páginas: `Catálogo`, `Contacto`, `Nosotros`, `Novedades`, `Reportes JMAC`, `Privacy Policy`, `Sample Page`, dos registros extraños | Extraer exclusivamente estructura nominal legítima; no migrar HTML sin limpiar |
| `themes.zip` | Tema padre `ona`, hijo `ona-architecture`, otros temas instalados; child `theme.json` incluye paleta base de plantilla y tipografías Urbanist/Inter | Metadatos orientativos, **nunca ejecutar/copiarlos** |
| `uploads.zip` | Material corporativo identificable (2026/03, 2026/05) y numerosos ficheros ajenos posteriores; también ZIP internos | Selección aprobable re-codificada en `assets_limpios/` |
| Resultados públicos indexados | Rutas, texto de portada, formulario, catálogo/categorías y carrito observables | Referencia para interacción y copy, sujeta a aprobación |

Se revisó el ZIP sin ejecutar scripts ni extraer contenidos ejecutables a un sitio en funcionamiento. Las imágenes del paquete fueron decodificadas con un procesador de imágenes y almacenadas de nuevo como PNG/JPEG, sin preservar código, archivos ocultos ni ZIP del origen. Ello reduce riesgos de trasladar artefactos ocultos, pero no sustituye revisión humana de la procedencia y los derechos de uso.

## 3. Resultado de `wpfd_posts.csv` (9 registros)

| ID | Página | Slug | Estado | Lectura exacta | Decisión |
|---|---|---|---|---|---|
| 6 | Catálogo | `catalogo` | publish | `[jmac_catalogo]` y un fragmento HTML ajeno/incrustado | Preservar ruta; **NO** copiar shortcode ni HTML |
| 1287 | Contacto | `contacto` | publish | `post_content` vacío | Crear estructura; contenido detallado pendiente |
| 1276 | Nosotros | `nosotros` | publish | `post_content` vacío | Crear estructura; contenido detallado pendiente |
| 1282 | Novedades | `novedades` | publish | `post_content` vacío | Crear estructura; noticias sin migrar |
| 4186 | Reportes JMAC | `reportes-jmac` | publish | `[jmac_reportes_portal]` | Posible función administrativa antigua; **alcance pendiente**, no exponer público ni copiar |
| 3 | Privacy Policy | `privacy-policy` | draft | Texto de ejemplo WordPress | No migrar; redactar política legal propia, aprobada |
| 2 | Sample Page | `sample-page` | publish | Página de ejemplo WP | No migrar |
| 11164 | Página no corporativa | slug extraño | publish | Contenido de apuestas ajeno al negocio | Rechazar |
| 11162 | tag | `tag` | draft | Vacía/no corporativa | Rechazar |

**Precisión crítica:** que una página tenga `post_content` vacío no significa necesariamente que careciera de contenido visual en WordPress. El sitio usa tema **Full Site Editing**; partes de su diseño pueden residir en `wp_template`, `wp_template_part`, `wp_navigation`, `wp_block` o personalizaciones de base de datos **no incluidas** en la exportación. Así, **no podemos asegurar una réplica visual píxel a píxel con estos archivos solamente**. Construir una aproximación fiel editable y registrar las diferencias pendientes de aprobación.

`show_on_front=posts` sugiere que en el momento del export WordPress mostraba el índice de entradas como inicio, pero puede reflejar configuración alterada; **no invalida** la portada corporativa que figuraba en vistas históricas.

## 4. Tema y colores

El par activo declarado: `Ona Architecture` (hijo) y `Ona` (padre). El child `theme.json` declara, entre otros, `#191919` texto, blanco `#ffffff`, `#e54d1e` primario, y tipografías Urbanist/Inter. **Es una configuración de plantilla arquitectónica, no evidencia de colores definitivos de JMAC.** El logotipo corporativo sí contiene azul/blanco y sugiere una paleta azul, blanco y neutros; los valores de `SEMILLA_CORPORATIVA_BORRADOR.json` son **propuestas de diseño**, no un pantone histórico validado.

El archivo `themes/ona-architecture/functions.php` mide aproximadamente 225 KiB, inicia con condicionales basados en cookies, decodificación de datos y carga dinámica de código, además de una larga sección ofuscada. Es **incompatible con un fuente confiable de personalización**. Ningún archivo PHP o `.htaccess` de ese respaldo forma parte de la entrega segura. No deducir autores ni mecanismo exacto sin análisis forense, que queda fuera del alcance.

## 5. Imágenes recuperables

`assets_limpios/` contiene 10 elementos aprobables: un logotipo, fotografías corporativas de escritorio/productos y personal, fondos industriales y el banner con texto incrustado. El listado de procedencia está en `MANIFIESTO_IMAGENES.csv`. Todos requieren verificación visual del propietario antes de publicar. Algunas imágenes casi idénticas son variantes de recorte; seleccionar una por sección para evitar descargas redundantes.

**No se incluyen**: imágenes de apuestas y otros contenidos ajenos, material procedente de 2026/08 o 2026/09, ZIP incluidos en uploads, `Screenshot_3.png` (POS ajeno), archivos ejecutables, CSS/JS/PHP de temas ni fuentes tipográficas binarias. Si Codex necesita tipografías web, debe usar un origen seguro y cumplir la licencia correspondiente; no transferir los archivos fuente antiguos como parte del paquete.

## 6. Portada y estructura pública histórica

Copia corporativa visible en versiones indexadas:

- **JMAC — LIDER EN EL MERCADO INDUSTRIAL** (también en `wpfd_options.csv`).
- “UN PRODUCTO CON 20 AÑOS DE EXPERIENCIA”.
- “Somos líderes gracias a la confianza que cada uno de nuestros clientes nos brinda día a día.”
- “ORGULLOSAMENTE TICOS”.
- “Unión de Experiencia, Tecnología y Calidad”.
- “Nuestra propuesta de producto siempre se ha basado en la experiencia adquirida en la venta de productos de línea industrial por más de dos décadas.”

Una imagen del respaldo incluye visualmente la variante **“Un producto creado con 20 años de experiencia”**. Es una diferencia de redacción entre materiales: consultar al propietario cuál usar y preferir texto HTML editable en vez de rasterizado al publicar.

Rutas/menú históricos: `/`, `/nosotros/`, `/contacto/`, `/novedades/`, `/catalogo/`, junto con referencias a `Inicio`, `Nosotros`, `Contáctanos`, `Novedades`, `Catálogo`.

## 7. Funciones del catálogo anterior (solo referencia de UX)

Históricamente se observaron seis categorías: `ADITIVOS`, `CADENAS`, `MUÑONERAS`, `OTROS`, `PIÑONES`, `ROLES`; buscador por nombre/código; botones “Cargar al carrito”; contador; preventa con nombre/teléfono/empresa. **NO precargar estas categorías ni un solo producto.** El propietario decidió reconstruir su inventario desde cero en el nuevo CMS. Implementar compatible el comportamiento general del selector de categorías a medida que se creen registros nuevos; la nueva página inicial de catálogo deberá mostrar un estado vacío bien diseñado (sin mensajes de error).

## 8. Navegación web inconsistente

Algunas versiones públicas indexadas siguen mostrando JMAC, mientras accesos actuales a las mismas rutas devuelven comercios ajenos. Este estado **impide confiar en la web actual como fuente para capturas visuales exactas**, redirecciones, precios o contenido comercial. Nunca copiar imágenes/productos ajenos ni HTML servido actualmente sin contraste con material verificado. En este informe no se repite contenido promocional ajeno al negocio.

## 9. Inventario de evidencias web para auditoría humana

- Sitio y portada histórica: https://jmaccr.com/
- Acerca de: https://jmaccr.com/nosotros/
- Contacto: https://jmaccr.com/contacto/
- Novedades: https://jmaccr.com/novedades/
- Catálogo: https://jmaccr.com/catalogo/

Estas URL pueden ofrecer contenido errático. Priorizar los archivos aportados y material gráfico aprobado por JMAC. No ligar enlaces a medios de terceros que no sean del negocio.

## 10. Matriz de confianza para implementación

| Elemento | Estado | Conducta de Codex |
|---|---|---|
| Nombre y eslogan | Confirmado en CSV | Borrador precargado |
| Logo J-MAC for the industry | Identificable en archivo gráfico | Importar como candidato con aprobación |
| Fotos 2026/03 y 2026/05 | Visualmente corporativas | Incluir como candidatos; no asumir estructura exacta |
| Copy portada | Referencia histórica pública | Crear bloque editable con aprobación de versión |
| Navegación cinco rutas | Coincide con evidencia pública y CSV | Implementar |
| Formulario nombre/teléfono/correo | Evidencia pública | Implementar; añadir mensaje/consentimiento como propuesta |
| Contenido completo Nosotros | **No recuperado** | No inventar; editor vacío y publicación controlada |
| Entradas de Novedades | **No exportadas** | Noticias empiezan vacías |
| Características anteriores catálogo | Históricas, parciales | Usar solo como patrón funcional |
| Productos, categorías, marcas, precios | Decisión explícita: cero | Tablas y seed **vacíos** |
| Portal Reportes JMAC | Shortcode encontrado; alcance desconocido | No reconstruir como página pública, pedir definición aparte |
| Identidad cromática exacta/maquetación WP | No verificable | Prototipo aprobable y diseño ajustable |
| Contactos oficiales, redes, domicilio | No verificados | Dejar sin configurar, no inventar |
