# JMAC web · JMAC 2.0
App limpia Laravel/PHP >=8.3, MySQL-MariaDB y Blade server-side para cPanel. Sitio responsive, CMS visual (21 bloques/tema/menús/medios/previews/revisiones), catálogo nuevo/carrito, preventas/contactos transaccionales/outbox SMTP, novedades/SEO, usuarios/RBAC/MFA/auditoría/backups cifrados/restore staging/diagnóstico/Cron finito.
Candidato integral para staging: aprobación final y hosting real pendientes. Sin WordPress/importación vieja/pagos. Cero productos/categorías/marcas/artículos/solicitudes/usuarios iniciales, sin contraseña default. Semilla DRAFT/fotos candidatas y contactos/legal pendientes. No modifica producción.
## Ver antes de subir
review/JMAC-2.0-VISTA-PREVIA.html: archivo único, navegador moderno, sin CDN/backend. Acciones locales/datos ficticios; panel/estados vacíos. PHP/MySQL del ZIP aporta seguridad/persistencia/SMTP reales.
## cPanel
docs/INSTALL_CPANEL.md: subir fuera de public_html; solo public/ o archivos_publicos al document root. vendor/build incluidos; sin Composer/Node en hosting. .env/storage privados, BD nueva y cuenta explícita mediante jmac:install-staging via Terminal o Cron. PHP web Y CLI >=8.3/extensiones indicadas. Conservar APP_KEY privada.
## Desarrollo / pruebas
Cloud: source /workspace/toolchain/activate; bash scripts/cloud-services.sh.
Composer oficial: php /workspace/toolchain/composer.phar install. npm ci && npm run build. .env privado; php artisan migrate --seed. Cuenta explícita: php artisan jmac:admin CORREO_PROPIO; contraseña solicitada en privado.
Tests solo SQLite memory o BD descartable *_test: php artisan test; DB_CONNECTION=mysql DB_DATABASE=jmac_test php artisan test. vendor/bin/pint --test, composer audit --locked, npm audit y tests/Browser. No tests/migrate:fresh sobre datos comerciales. CI PHP8.3/8.4+MySQL8 configurada, no ejecutada remotamente.
Guías: docs/ADMIN_MANUAL.md, BACKUP_RESTORE.md, UPDATE_ROLLBACK.md, STATUS.md, QA_MATRIX.md, adr/001-stack.md. Fuentes leídas/verificadas fuera del release; sin respaldos contaminados.
