# Estado JMAC 2.0 · 2026-10-10
Código integral para revisión en staging. No autorizado para producción ni aprobado visualmente.

## Hitos
H0: todos README/01–09/JSON/CSV e informe leídos, 30 checksums correctos, ZIP duplicados idénticos; fuentes fuera del release. Repo inicial vacío, sin WP ni importación. PHP8.3/MySQL/phpMyAdmin confirmados por dueño; proveedor/versión DB/CLI/SMTP/Cron/document root pendientes. ADR Laravel13/Blade/Vite/PHP>=8.3/cPanel.
H1: migraciones técnicas, semilla 0 catálogo/solicitudes/noticias/usuarios, Auth/RBAC/MFA/CSRF/limits/auditoría/subidas, CI y provisionado privado. Admin explícito; sin contraseña default.
H2: cinco rutas SSR, responsive, SEO/noindex y vacíos, menú/pie; navegador 25 combinaciones sin overflow.
H3: CMS visual real de 21 bloques, drag/orden/repetidores/columnas/undo/redo/vistas/previews/revisiones/secciones, diseño/menu/publicación/rollback, raster reencode/miniaturas/ALT/aprobación y PDF reconstruido.
H4: catálogo nuevo CRUD/ciclos/SKU/estados/galerías/PDF/especificaciones/tags/SEO, filtros/búsqueda acentuada/paginación/fichas/carrito. Fixture 1.000 productos solo prueba.
H5: solicitudes transaccionales/idempotentes/sesión/consecutivos/snapshots/eventos, PII cifrada, bandejas/CSV/anonimización/outbox SMTP privado/configuración/legal/WhatsApp. Concurrencia real: 4 workers/10 intentos/7 consecutivos únicos, 4 reintentos mismo token=1 fila. SMTP controlado local: 7 aceptados.
H6: novedades con constructor/revisiones/programación, SEO/redirects internos, invitación segura en outbox/roles/sesiones/MFA/último dueño protegido, copias privadas cifradas/restore staging, diagnóstico/auditoría/Cron finito/prueba SMTP/cache.
H7: HTML autónomo local (fotos/textos propuesta, panel y datos locales), paquete con vendor runtime/build, manuales y matriz48/evidencia. cPanel del dueño, QA externo/T048 pendientes.

## Pruebas finales
64 tests/431 aserciones PASSED en SQLite y MariaDB 11.8.6, PHP8.4.26. Pint PASSED. Composer/npm audit: 0 avisos. Navegador real: Auth/MFA, constructor/media, altas nuevas de catálogo, carrito, preventa/reintento/seguimiento/contacto, novedad y restore con cierre de sesiones. Bases QA eliminadas/medios QA retirados; desarrollo mantiene ceros.
HTML local: edición/aprobación/publicación, categorías/marcas/producto nuevos, búsqueda/cart/solicitud/histórico/persistencia y cinco anchos, sin errores JS, navegación teclado/skip y backup local con rechazo de estilos inseguros. Se probó por HTTP local: Chromium administrado del cloud bloquea file://. Archivo no necesita HTTP en navegador estándar; no se afirma file:// verificado en este cloud.

## Código, rutas y migraciones
Reportes HITO_2.md a HITO_6.md y arquitectura/contratos. Core + extend_cms/catalog/sales/system. Rutas públicas cinco, fichas/noticias/privacy/media/search/preorders/contacts/SEO; admin CMS/catálogo/ventas/comunicación/sistema, middleware Auth/MFA/RBAC/CSRF. Lista final-routes.txt.
Evidencia docs/evidence/final-*, h2–h6*. Capturas son reales de pruebas con datos ficticios. Reportes históricos conservan el estado de su hito; final-* es autoridad del conjunto actual.

Contrato adicional: modo SEO público simulado (HTTPS simulado solo router QA), sitemap 1001 rutas publicadas sin borrador, imagen categoría aprobada, retirada de novedad 404 y 1.000 productos nuevos: HTTP medio 429.56ms local/12 por página. robots.txt estático de scaffold eliminado para respetar controlador por entorno. No métrica del hosting.

## Pendientes materiales
Sin acceso cPanel real; PHP8.3 web/CLI, MySQL8 del hosting, rewrite/SSL/SMTP/Cron/document root y recursos no verificados. CI GitHub configurada, no ejecutada remota. Lighthouse/WCAG completo pendientes. No marcar 48/48 aprobado.
Contacto/historia/misión/legal no recuperados permanecen editables/pendientes. Semilla DRAFT, diez medios candidatos privados, ninguna aprobación automática. Publicación debe hacerse por el dueño. Réplica exacta no verificada.
HTML guarda solo en navegador, no ejecuta PHP/MFA/SMTP ni envía solicitudes a JMAC. La app del ZIP persiste/valida en MySQL. Producción/DNS/cPanel no modificados.
