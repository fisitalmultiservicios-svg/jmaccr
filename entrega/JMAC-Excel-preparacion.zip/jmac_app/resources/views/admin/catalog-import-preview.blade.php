@extends('layouts.admin')
@section('content')
<p class="eyebrow">CATÁLOGO · EXCEL</p><h1>{{ $batch->status==='completed'?'Importación aplicada':'Revisión de importación' }}</h1><p>{{ $mapping['source_name'] }} · {{ $mapping['mode']==='replace'?'Reemplazar catálogo':'Sumar al catálogo' }}</p>
<div class="dashboard-grid">@foreach(['new'=>'Nuevos','updated'=>'Actualizados','restored'=>'Restaurados','retired'=>'Retirados','errors'=>'Errores'] as $key=>$label)<div class="card"><strong>{{ $counts[$key]??0 }}</strong><p>{{ $label }}</p></div>@endforeach</div>
@if($batch->status==='processing')
<section class="card"><h2>Preparando fotografías</h2><p>{{ $mapping['photos_prepared']??0 }} de {{ count($mapping['photo_parts']??[]) }} fotografías listas. El catálogo todavía no ha cambiado. Mantén esta pantalla abierta; se procesan hasta diez fotos por petición.</p><p id="excel-photo-progress" role="status" aria-live="polite">Puedes dejar que continúe automáticamente o pulsar el botón una vez.</p><form id="prepare-excel-photos" method="post" action="/admin/catalog/imports/{{ $batch->id }}/prepare">@csrf<button type="submit">Continuar preparación de fotografías</button></form><form id="cancel-excel-photos" method="post" action="/admin/catalog/imports/{{ $batch->id }}/cancel">@csrf<button type="submit" class="secondary">Cancelar sin cambiar el catálogo</button></form></section>
<script nonce="{{ request()->attributes->get('csp_nonce') }}">
(function(){
    const form=document.getElementById('prepare-excel-photos');
    if(!form){return;}
    let submitting=false;
    let timer;
    form.addEventListener('submit',function(event){
        if(submitting){event.preventDefault();return;}
        submitting=true;
        clearTimeout(timer);
        form.querySelector('button[type="submit"]').disabled=true;
        document.getElementById('excel-photo-progress').textContent='Preparando fotografías. El avance se guarda antes de continuar.';
    });
    document.getElementById('cancel-excel-photos').addEventListener('submit',function(){
        submitting=true;
        clearTimeout(timer);
    });
    window.addEventListener('pageshow',function(event){if(event.persisted){window.location.reload();}});
    @if(!$errors->any())
    timer=setTimeout(function(){if(!submitting){form.requestSubmit();}},{{ session('photo_retry_delay')===5000?5000:500 }});
    @endif
})();
</script>
@elseif($batch->status==='ready')
<section class="card"><h2>3. Confirma los cambios</h2><p>Todavía no se ha modificado ningún producto. Esta vista previa dura dos horas. Antes de guardar se creará una copia privada cifrada.</p>@if($mapping['mode']==='replace')<p class="error">El catálogo activo quedará formado únicamente por este Excel. Los productos ausentes pasarán a papelera. El histórico de preventas permanece intacto.</p>@endif<form method="post" action="/admin/catalog/imports/{{ $batch->id }}/apply">@csrf<label><input type="checkbox" name="confirm" value="1" required>He revisado el archivo y autorizo estos cambios.</label>@if($mapping['mode']==='replace')<label>Escribe REEMPLAZAR para confirmar<input name="phrase" autocomplete="off" required maxlength="30"></label>@endif
@if(count($mapping['photo_parts']??[]) && $canApprovePhotos)<label><input type="checkbox" name="approve_photos" value="1">Confirmo que tengo permiso para usar estas fotografías y autorizo su publicación.</label>@endif
@if($canPublishProducts)<label><input type="checkbox" name="publish_products" value="1">Publicar los productos de este Excel al terminar. Sin marcar, se conservan los estados anteriores y los nuevos quedan en borrador.</label>@endif
@if(count($mapping['photo_parts']??[]))<p>Si publicas productos con fotografías nuevas, debes aprobar su uso. Si no apruebas las fotos, se guardan como candidatos privados y los productos nuevos quedan en borrador.</p>@endif
<button type="submit">{{ $mapping['mode']==='replace'?'Confirmar reemplazo del catálogo':'Confirmar carga de productos' }}</button></form><form method="post" action="/admin/catalog/imports/{{ $batch->id }}/cancel">@csrf<button class="secondary" type="submit">Cancelar sin cambiar el catálogo</button></form></section>
<section class="card table-wrap"><h2>Productos del Excel</h2><table><thead><tr><th>Fila</th><th>SKU</th><th>Nombre</th><th>Categoría</th><th>Marca</th><th>Fotografías</th><th>Estado</th></tr></thead><tbody>@foreach($rows as $row)<tr><td>{{ $row['line'] }}</td><td>{{ $row['fields']['sku'] }}</td><td>{{ $row['fields']['name'] }}</td><td>{{ $row['fields']['category']??'Conservar / sin categoría' }}</td><td>{{ $row['fields']['brand']??'Conservar / sin marca' }}</td><td>@foreach($row['photos']??[] as $part)@php($photoIndex=array_search($part,$mapping['photo_parts']??[],true))<img src="/admin/catalog/imports/{{ $batch->id }}/photos/{{ $photoIndex }}" alt="{{ $row['fields']['name'] }}" width="80" height="60" loading="lazy">@endforeach</td><td>{{ ['draft'=>'Borrador','published'=>'Publicado','hidden'=>'Oculto','archived'=>'Archivado'][$row['fields']['status']??'']??'Conservar / borrador nuevo' }}</td></tr>@endforeach</tbody></table><div class="actions">@if($pageNumber>1)<a href="?page={{ $pageNumber-1 }}">Anterior</a>@endif<span>Página {{ $pageNumber }} de {{ max(1,(int)ceil($counts['total']/50)) }}</span>@if($pageNumber*50<$counts['total'])<a href="?page={{ $pageNumber+1 }}">Siguiente</a>@endif</div></section>
@elseif($batch->status==='invalid')
<section class="card"><h2>Corrige el Excel antes de continuar</h2><p>No se ha modificado el catálogo. Ninguna fila se importará mientras haya errores.</p><table><thead><tr><th>Fila</th><th>Problema</th></tr></thead><tbody>@foreach($errorsList as $error)<tr><td>{{ $error->row_number?:'Archivo' }}</td><td>{{ $error->safe_error }}</td></tr>@endforeach</tbody></table>{{ $errorsList->links() }}</section>
@elseif($batch->status==='completed')
<section class="card"><h2>Catálogo guardado</h2><p>La operación ya fue aplicada. Reenviar la confirmación no vuelve a importar ni duplica productos.</p>@if($mapping['backup']??null)<p>Copia cifrada anterior: {{ $mapping['backup'] }}. El propietario puede consultarla en Sistema → Backups.</p>@endif<a class="button" href="/admin/catalog/products">Ver productos</a><a class="button secondary" href="/catalogo/" target="_blank" rel="noopener">Ver catálogo público</a></section>
@else
<section class="card"><p>Esta vista previa está cancelada o vencida. El catálogo no se modificó por ella.</p></section>
@endif
<a href="/admin/catalog/imports">Volver a cargar Excel</a>
@endsection
